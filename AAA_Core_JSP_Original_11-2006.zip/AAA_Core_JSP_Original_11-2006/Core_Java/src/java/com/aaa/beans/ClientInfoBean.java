/*
 * ClientInfoBean.java
 *
 * Created on May 21, 2006, 7:56 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class ClientInfoBean {
    
    private Integer clientId = null;
    
    private Integer clientContactId = null;

    private String propertyName;
    
    private String contactPersonFirstName;

    private String contactPersonLastName;

    private Double applicationFee;

    private String stateCode = "AZ";

    private String addressLine1;

    private String addressLine2;

    private String addressLine3;

    private String city;

    private String zipCode;

    private String homePhoneNumber;

    private String mobilePhoneNumber;

    private String faxPhoneNumber;

    private String email;
    
    private String propertyManagementCompanyName;
    
    private Integer propertyManagementCompanyId = null;
    
    private String propertyManagementCompanyAddressLine1;

    private String propertyManagementCompanyAddressLine2;

    private String propertyManagementCompanyAddressLine3;

    private String propertyManagementCompanyCity;
    
    private String propertyManagementCompanyStateCode = "AZ";

    private String propertyManagementCompanyZipCode;

    private String propertyManagementCompanyHomePhoneNumber;

    private String propertyManagementCompanyMobilePhoneNumber;

    private String propertyManagementCompanyFaxPhoneNumber;

    private String propertyManagementCompanyEmail;
    
    private Integer propertyManagementCompanyContactId = null;
    
    private ApplicationDecisionStatementBean[] ApplicationDecisionStatementBeans = new ApplicationDecisionStatementBean[0];
    
    private ApplicationBean[] ApplicationBeans = new ApplicationBean[0];
    
    //Client security fields
     private Integer clientSecurityId;
     
    private String clientSecurityUserId;
    
    private String clientSecurityPassword;
    
    private String clientSecurityHtLogin;
    
    private String clientSecurityHtPassword;
    
    private Integer clientSecurityStatusId;
    
    //private Integer clientSecurityAccessId;
    private Boolean clientAdminAccess = new Boolean (false);

    private Boolean clientEmploymentAccess= new Boolean (false);

    private Boolean clientSecurityAccess = new Boolean (false);
    
    //-- END Client security fields
    
    private boolean userManagementContactAsBilling = false;
    
    private ClientCustomNoteBean[] clientCustomNoteBeans = new ClientCustomNoteBean[0];
    
    private Integer[] autoDenyCriteriaId = null;
    
    private SelectedAutoDenyCriteriaBean[] selectedAutoDenyCriteriaBeans = new SelectedAutoDenyCriteriaBean[0];

    private int numOfDaysOldApplication = 30;
    
    private String webUrl;
     
    public Integer getClientId()
    {
        return clientId;
    }

    public void setClientId(Integer clientId)
    {
        this.clientId = clientId;
    }

    public String getPropertyName()
    {
        return propertyName;
    }

    public void setPropertyName(String propertyName)
    {
        this.propertyName = propertyName;
    }

    public String getContactPersonFirstName()
    {
        return contactPersonFirstName;
    }

    public void setContactPersonFirstName(String contactPersonFirstName)
    {
        this.contactPersonFirstName = contactPersonFirstName;
    }

    public String getContactPersonLastName()
    {
        return contactPersonLastName;
    }

    public void setContactPersonLastName(String contactPersonLastName)
    {
        this.contactPersonLastName = contactPersonLastName;
    }

    public Double getApplicationFee()
    {
        return applicationFee;
    }

    public void setApplicationFee(Double applicationFee)
    {
        this.applicationFee = applicationFee;
    }

    public String getStateCode()
    {
        return stateCode;
    }

    public void setStateCode(String stateCode)
    {
        this.stateCode = stateCode;
    }

    public String getAddressLine1()
    {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1)
    {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2()
    {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2)
    {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3()
    {
        return addressLine3;
    }

    public void setAddressLine3(String addressLine3)
    {
        this.addressLine3 = addressLine3;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getZipCode()
    {
        return zipCode;
    }

    public void setZipCode(String zipCode)
    {
        this.zipCode = zipCode;
    }

    public String getHomePhoneNumber()
    {
        return homePhoneNumber;
    }

    public void setHomePhoneNumber(String homePhoneNumber)
    {
        this.homePhoneNumber = homePhoneNumber;
    }

    public String getMobilePhoneNumber()
    {
        return mobilePhoneNumber;
    }

    public void setMobilePhoneNumber(String mobilePhoneNumber)
    {
        this.mobilePhoneNumber = mobilePhoneNumber;
    }

    public String getFaxPhoneNumber()
    {
        return faxPhoneNumber;
    }

    public void setFaxPhoneNumber(String faxPhoneNumber)
    {
        this.faxPhoneNumber = faxPhoneNumber;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getPropertyManagementCompanyName()
    {
        return propertyManagementCompanyName;
    }

    public void setPropertyManagementCompanyName(String propertyManagementCompanyName)
    {
        this.propertyManagementCompanyName = propertyManagementCompanyName;
    }

    public Integer getPropertyManagementCompanyId()
    {
        return propertyManagementCompanyId;
    }

    public void setPropertyManagementCompanyId(Integer propertyManagementCompanyId)
    {
        this.propertyManagementCompanyId = propertyManagementCompanyId;
    }

    public String getPropertyManagementCompanyAddressLine1()
    {
        return propertyManagementCompanyAddressLine1;
    }

    public void setPropertyManagementCompanyAddressLine1(String propertyManagementCompanyAddressLine1)
    {
        this.propertyManagementCompanyAddressLine1 = propertyManagementCompanyAddressLine1;
    }

    public String getPropertyManagementCompanyAddressLine2()
    {
        return propertyManagementCompanyAddressLine2;
    }

    public void setPropertyManagementCompanyAddressLine2(String propertyManagementCompanyAddressLine2)
    {
        this.propertyManagementCompanyAddressLine2 = propertyManagementCompanyAddressLine2;
    }

    public String getPropertyManagementCompanyAddressLine3()
    {
        return propertyManagementCompanyAddressLine3;
    }

    public void setPropertyManagementCompanyAddressLine3(String propertyManagementCompanyAddressLine3)
    {
        this.propertyManagementCompanyAddressLine3 = propertyManagementCompanyAddressLine3;
    }

    public String getPropertyManagementCompanyCity()
    {
        return propertyManagementCompanyCity;
    }

    public void setPropertyManagementCompanyCity(String propertyManagementCompanyCity)
    {
        this.propertyManagementCompanyCity = propertyManagementCompanyCity;
    }

    public String getPropertyManagementCompanyStateCode()
    {
        return propertyManagementCompanyStateCode;
    }

    public void setPropertyManagementCompanyStateCode(String propertyManagementCompanyStateCode)
    {
        this.propertyManagementCompanyStateCode = propertyManagementCompanyStateCode;
    }

    public String getPropertyManagementCompanyZipCode()
    {
        return propertyManagementCompanyZipCode;
    }

    public void setPropertyManagementCompanyZipCode(String propertyManagementCompanyZipCode)
    {
        this.propertyManagementCompanyZipCode = propertyManagementCompanyZipCode;
    }

    public String getPropertyManagementCompanyHomePhoneNumber()
    {
        return propertyManagementCompanyHomePhoneNumber;
    }

    public void setPropertyManagementCompanyHomePhoneNumber(String propertyManagementCompanyHomePhoneNumber)
    {
        this.propertyManagementCompanyHomePhoneNumber = propertyManagementCompanyHomePhoneNumber;
    }

    public String getPropertyManagementCompanyMobilePhoneNumber()
    {
        return propertyManagementCompanyMobilePhoneNumber;
    }

    public void setPropertyManagementCompanyMobilePhoneNumber(String propertyManagementCompanyMobilePhoneNumber)
    {
        this.propertyManagementCompanyMobilePhoneNumber = propertyManagementCompanyMobilePhoneNumber;
    }

    public String getPropertyManagementCompanyFaxPhoneNumber()
    {
        return propertyManagementCompanyFaxPhoneNumber;
    }

    public void setPropertyManagementCompanyFaxPhoneNumber(String propertyManagementCompanyFaxPhoneNumber)
    {
        this.propertyManagementCompanyFaxPhoneNumber = propertyManagementCompanyFaxPhoneNumber;
    }

    public String getPropertyManagementCompanyEmail()
    {
        return propertyManagementCompanyEmail;
    }

    public void setPropertyManagementCompanyEmail(String propertyManagementCompanyEmail)
    {
        this.propertyManagementCompanyEmail = propertyManagementCompanyEmail;
    }

    public Integer getClientContactId()
    {
        return clientContactId;
    }

    public void setClientContactId(Integer clientContactId)
    {
        this.clientContactId = clientContactId;
    }

    public Integer getPropertyManagementCompanyContactId()
    {
        return propertyManagementCompanyContactId;
    }

    public void setPropertyManagementCompanyContactId(Integer propertyManagementCompanyContactId)
    {
        this.propertyManagementCompanyContactId = propertyManagementCompanyContactId;
    }

    public ApplicationDecisionStatementBean[] getApplicationDecisionStatementBeans()
    {
        return ApplicationDecisionStatementBeans;
    }

    public void setApplicationDecisionStatementBeans(ApplicationDecisionStatementBean[] ApplicationDecisionStatementBeans)
    {
        this.ApplicationDecisionStatementBeans = ApplicationDecisionStatementBeans;
    }

    public ApplicationBean[] getApplicationBeans()
    {
        return ApplicationBeans;
    }

    public void setApplicationBeans(ApplicationBean[] ApplicationBeans)
    {
        this.ApplicationBeans = ApplicationBeans;
    }

    public String getClientSecurityUserId()
    {
        return clientSecurityUserId;
    }

    public void setClientSecurityUserId(String clientSecurityUserId)
    {
        this.clientSecurityUserId = clientSecurityUserId;
    }

    public String getClientSecurityPassword()
    {
        return clientSecurityPassword;
    }

    public void setClientSecurityPassword(String clientSecurityPassword)
    {
        this.clientSecurityPassword = clientSecurityPassword;
    }

    public String getClientSecurityHtLogin()
    {
        return clientSecurityHtLogin;
    }

    public void setClientSecurityHtLogin(String clientSecurityHtLogin)
    {
        this.clientSecurityHtLogin = clientSecurityHtLogin;
    }

    public String getClientSecurityHtPassword()
    {
        return clientSecurityHtPassword;
    }

    public void setClientSecurityHtPassword(String clientSecurityHtPassword)
    {
        this.clientSecurityHtPassword = clientSecurityHtPassword;
    }

    public Integer getClientSecurityStatusId()
    {
        return clientSecurityStatusId;
    }

    public void setClientSecurityStatusId(Integer clientSecurityStatusId)
    {
        this.clientSecurityStatusId = clientSecurityStatusId;
    }
    
    public boolean getUserManagementContactAsBilling()
    {
        return userManagementContactAsBilling;
    }

    public void setUserManagementContactAsBilling(boolean userManagementContactAsBilling)
    {
        this.userManagementContactAsBilling = userManagementContactAsBilling;
    }

    public ClientCustomNoteBean[] getClientCustomNoteBeans()
    {
        return clientCustomNoteBeans;
    }

    public void setClientCustomNoteBeans(ClientCustomNoteBean[] clientCustomNoteBeans)
    {
        this.clientCustomNoteBeans = clientCustomNoteBeans;
    }
    
    public Integer getClientSecurityId()
    {
        return clientSecurityId;
    }

    public void setClientSecurityId(Integer clientSecurityId)
    {
        this.clientSecurityId = clientSecurityId;
    }
    
    public Boolean getClientAdminAccess() {
		return this.clientAdminAccess;
    }

    public void setClientAdminAccess(Boolean clientAdminAccess) {
            this.clientAdminAccess = clientAdminAccess;
    }

    public Boolean getClientEmploymentAccess() {
            return this.clientEmploymentAccess;
    }

    public void setClientEmploymentAccess(Boolean clientEmploymentAccess) {
            this.clientEmploymentAccess = clientEmploymentAccess;
    }

    public Boolean getClientSecurityAccess() {
            return this.clientSecurityAccess;
    }

    public void setClientSecurityAccess(Boolean clientSecurityAccess) {
            this.clientSecurityAccess = clientSecurityAccess;
    }
    
    public Integer[] getAutoDenyCriteriaId() {
        return autoDenyCriteriaId;
    }

    public void setAutoDenyCriteriaId(Integer[] autoDenyCriteriaId) {
        this.autoDenyCriteriaId = autoDenyCriteriaId;
    }

    public SelectedAutoDenyCriteriaBean[] getSelectedAutoDenyCriteriaBeans() {
        return selectedAutoDenyCriteriaBeans;
    }

    public void setSelectedAutoDenyCriteriaBeans(SelectedAutoDenyCriteriaBean[] selectedAutoDenyCriteriaBeans) {
        this.selectedAutoDenyCriteriaBeans = selectedAutoDenyCriteriaBeans;
    }

    public int getNumOfDaysOldApplication() {
        return numOfDaysOldApplication;
    }

    public void setNumOfDaysOldApplication(int numOfDaysOldApplication) {
        this.numOfDaysOldApplication = numOfDaysOldApplication;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }
    
}
