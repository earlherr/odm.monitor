/*
 * ApplicantBean.java
 *
 * Created on June 17, 2006, 9:30 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Mohammed Ansari
 */
public class ApplicantBean {
    private Integer applicantId;
    
    private Integer applicationId;
    
    private Integer userId;
    
    private Integer userTypeId;
    
    private Integer genderId;
    
    private String firstName = "";
    
    private String middleName = "";
    
    private String lastName = "";
    
    private Integer contactInfoId;
    
    private String stateCode = "AZ";
    
    private String addressLine1 = "";
    
    private String addressLine2 = "";
    
    private String addressLine3 = "";
    
    private String city = "";
    
    private String zipCode = "";
    
    private String homePhoneNumber = "";
    
    private String mobilePhoneNumber = "";
    
    private String faxPhoneNumber = "";
    
    private String email = "";
    
    private String dateOfBirthString;
    
     private Date dateOfBirth;
    
    private String socialSecurityNumber;
    
    private Boolean applicantCompleted = new Boolean (false);
    
    /********************************************************/
    /*Criminal info 
     */
    private Integer criminalInfoId;

    private Integer pendingWarrants;

    private Integer feloniesOverFiveYears;

    private Integer feloniesUnderFiveYears;

    private Integer misdemeanorsOverFiveYears;

    private Integer misdemeanorsUnderFiveYears;

    private String criminalComments = "NONE";
    
    /*********************************************************/
    /*Credit info */
    private Integer creditInfoId;

    private Integer positiveCredit;

    private Integer negativeCredit;

    private Integer numberOfCollections;

    private Integer numberOfJudgements;

    private Integer ficoScore;

    private Integer evictionsOverThreeYears;

    private Integer evictionsUnderThreeYears;

    private Integer bankruptcyOverSevenYears;

    private Integer bankruptcyUnderSevenYears;

    private String creditComments = "NONE";
    
    private Boolean applicantDenied = new Boolean (false);
    
    private EmploymentRecordBean[] employmentRecordBeans = new EmploymentRecordBean[0];
    
    private RentalRecordBean[] rentalRecordBeans = new RentalRecordBean [0];
    
    private ArrayList<EmploymentRecordBean> previousEmployments = new ArrayList<EmploymentRecordBean> (0);
    
    private ArrayList<EmploymentRecordBean> currentEmployments = new ArrayList<EmploymentRecordBean> (0);
    
    private ArrayList<RentalRecordBean> currentRental = new ArrayList<RentalRecordBean> (0);
    
    private ArrayList<RentalRecordBean> previousRental = new ArrayList<RentalRecordBean> (0);
    
    private CriminalRecordBean[] criminalRecordBeans = new CriminalRecordBean[0];
    
    private BankruptcyRecordBean[] bankruptcyRecordBeans = new BankruptcyRecordBean[0];
    
    private EvictionRecordBean[] evictionRecordBeans = new EvictionRecordBean[0];
    
    private DmvRecordBean[] dmvRecordBeans = new DmvRecordBean[0];
     
    /** Creates a new instance of ApplicantBean */
    public ApplicantBean() {
    }
    
    public Integer getApplicantId() {
        return applicantId;
    }
    
    public void setApplicantId(Integer applicantId) {
        this.applicantId = applicantId;
    }
    
    public Integer getApplicationId() {
        return applicationId;
    }
    
    public void setApplicationId(Integer applicationId) {
        this.applicationId = applicationId;
    }
    
    public Integer getUserId() {
        return userId;
    }
    
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    
    public Integer getUserTypeId() {
        return userTypeId;
    }
    
    public void setUserTypeId(Integer userTypeId) {
        this.userTypeId = userTypeId;
    }
    
    public Integer getGenderId() {
        return genderId;
    }
    
    public void setGenderId(Integer genderId) {
        this.genderId = genderId;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getMiddleName() {
        return middleName;
    }
    
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public Integer getContactInfoId() {
        return contactInfoId;
    }
    
    public void setContactInfoId(Integer contactInfoId) {
        this.contactInfoId = contactInfoId;
    }
    
    public String getStateCode() {
        return stateCode;
    }
    
    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }
    
    public String getAddressLine1() {
        return addressLine1;
    }
    
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }
    
    public String getAddressLine2() {
        return addressLine2;
    }
    
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }
    
    public String getAddressLine3() {
        return addressLine3;
    }
    
    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }
    
    public String getCity() {
        return city;
    }
    
    public void setCity(String city) {
        this.city = city;
    }
    
    public String getZipCode() {
        return zipCode;
    }
    
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
    
    public String getHomePhoneNumber() {
        return homePhoneNumber;
    }
    
    public void setHomePhoneNumber(String homePhoneNumber) {
        this.homePhoneNumber = homePhoneNumber;
    }
    
    public String getMobilePhoneNumber() {
        return mobilePhoneNumber;
    }
    
    public void setMobilePhoneNumber(String mobilePhoneNumber) {
        this.mobilePhoneNumber = mobilePhoneNumber;
    }
    
    public String getFaxPhoneNumber() {
        return faxPhoneNumber;
    }
    
    public void setFaxPhoneNumber(String faxPhoneNumber) {
        this.faxPhoneNumber = faxPhoneNumber;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }

    public String getDateOfBirthString() {
        return dateOfBirthString;
    }

    public void setDateOfBirthString(String dateOfBirthString) {
        this.dateOfBirthString = dateOfBirthString;
    }
    
    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        
        try
        {
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

            dateOfBirthString = formatter.format(dateOfBirth);
        }
        catch (Exception e)
        {
            
        }
    }

    public String getSocialSecurityNumber() {
        return socialSecurityNumber;
    }

    public void setSocialSecurityNumber(String socialSecurityNumber) {
        this.socialSecurityNumber = socialSecurityNumber;
    }
    
     public Boolean getApplicantCompleted() {
		return this.applicantCompleted;
    }

    public void setApplicantCompleted(Boolean applicantCompleted) {
            this.applicantCompleted = applicantCompleted;
    }
    
    public Integer getCriminalInfoId() {
        return criminalInfoId;
    }

    public void setCriminalInfoId(Integer criminalInfoId) {
        this.criminalInfoId = criminalInfoId;
    }

    public Integer getPendingWarrants() {
        return pendingWarrants;
    }

    public void setPendingWarrants(Integer pendingWarrants) {
        this.pendingWarrants = pendingWarrants;
    }

    public Integer getFeloniesOverFiveYears() {
        return feloniesOverFiveYears;
    }

    public void setFeloniesOverFiveYears(Integer feloniesOverFiveYears) {
        this.feloniesOverFiveYears = feloniesOverFiveYears;
    }

    public Integer getFeloniesUnderFiveYears() {
        return feloniesUnderFiveYears;
    }

    public void setFeloniesUnderFiveYears(Integer feloniesUnderFiveYears) {
        this.feloniesUnderFiveYears = feloniesUnderFiveYears;
    }

    public Integer getMisdemeanorsOverFiveYears() {
        return misdemeanorsOverFiveYears;
    }

    public void setMisdemeanorsOverFiveYears(Integer misdemeanorsOverFiveYears) {
        this.misdemeanorsOverFiveYears = misdemeanorsOverFiveYears;
    }

    public Integer getMisdemeanorsUnderFiveYears() {
        return misdemeanorsUnderFiveYears;
    }

    public void setMisdemeanorsUnderFiveYears(Integer misdemeanorsUnderFiveYears) {
        this.misdemeanorsUnderFiveYears = misdemeanorsUnderFiveYears;
    }

    public String getCriminalComments() {
         if (criminalComments == null || criminalComments.equals(""))
            return "None";
        else
            return criminalComments;
    }

    public void setCriminalComments(String criminalComments) {
        this.criminalComments = criminalComments;
    }

    public Integer getCreditInfoId() {
        return creditInfoId;
    }

    public void setCreditInfoId(Integer creditInfoId) {
        this.creditInfoId = creditInfoId;
    }

    public Integer getPositiveCredit() {
        return positiveCredit;
    }

    public void setPositiveCredit(Integer positiveCredit) {
        this.positiveCredit = positiveCredit;
    }

    public Integer getNegativeCredit() {
        return negativeCredit;
    }

    public void setNegativeCredit(Integer negativeCredit) {
        this.negativeCredit = negativeCredit;
    }

    public Integer getNumberOfCollections() {
        return numberOfCollections;
    }

    public void setNumberOfCollections(Integer numberOfCollections) {
        this.numberOfCollections = numberOfCollections;
    }

    public Integer getNumberOfJudgements() {
        return numberOfJudgements;
    }

    public void setNumberOfJudgements(Integer numberOfJudgements) {
        this.numberOfJudgements = numberOfJudgements;
    }

    public Integer getFicoScore() {
        return ficoScore;
    }

    public void setFicoScore(Integer ficoScore) {
        this.ficoScore = ficoScore;
    }

    public Integer getEvictionsOverThreeYears() {
        return evictionsOverThreeYears;
    }

    public void setEvictionsOverThreeYears(Integer evictionsOverThreeYears) {
        this.evictionsOverThreeYears = evictionsOverThreeYears;
    }

    public Integer getEvictionsUnderThreeYears() {
        return evictionsUnderThreeYears;
    }

    public void setEvictionsUnderThreeYears(Integer evictionsUnderThreeYears) {
        this.evictionsUnderThreeYears = evictionsUnderThreeYears;
    }

    public Integer getBankruptcyOverSevenYears() {
        return bankruptcyOverSevenYears;
    }

    public void setBankruptcyOverSevenYears(Integer bankruptcyOverSevenYears) {
        this.bankruptcyOverSevenYears = bankruptcyOverSevenYears;
    }

    public Integer getBankruptcyUnderSevenYears() {
        return bankruptcyUnderSevenYears;
    }

    public void setBankruptcyUnderSevenYears(Integer bankruptcyUnderSevenYears) {
        this.bankruptcyUnderSevenYears = bankruptcyUnderSevenYears;
    }

    public String getCreditComments() {
        if (creditComments == null || creditComments.equals(""))
            return "None";
        else
            return creditComments;
    }

    public void setCreditComments(String creditComments) {
        this.creditComments = creditComments;
    }
    
    public Boolean getApplicantDenied() {
		return this.applicantDenied;
    }

    public void setApplicantDenied(Boolean applicantDenied) {
            this.applicantDenied = applicantDenied;
    }

    public EmploymentRecordBean[] getEmploymentRecordBeans()
    {
        return employmentRecordBeans;
    }

    public void setEmploymentRecordBeans(EmploymentRecordBean[] employmentRecords)
    {
        this.employmentRecordBeans = employmentRecords;
    }

    public ArrayList<EmploymentRecordBean> getPreviousEmployments() {
        return previousEmployments;
    }

    public void setPreviousEmployments(ArrayList<EmploymentRecordBean> previousEmployments) {
        this.previousEmployments = previousEmployments;
    }

    public ArrayList<EmploymentRecordBean> getCurrentEmployments() {
        return currentEmployments;
    }

    public void setCurrentEmployments(ArrayList<EmploymentRecordBean> currentEmployments) {
        this.currentEmployments = currentEmployments;
    }

    public RentalRecordBean[] getRentalRecordBeans() {
        return rentalRecordBeans;
    }

    public void setRentalRecordBeans(RentalRecordBean[] rentalRecordBeans) {
        this.rentalRecordBeans = rentalRecordBeans;
    }

    public CriminalRecordBean[] getCriminalRecordBeans() {
        return criminalRecordBeans;
    }

    public void setCriminalRecordBeans(CriminalRecordBean[] criminalRecordBeans) {
        this.criminalRecordBeans = criminalRecordBeans;
    }

    public BankruptcyRecordBean[] getBankruptcyRecordBeans() {
        return bankruptcyRecordBeans;
    }

    public void setBankruptcyRecordBeans(BankruptcyRecordBean[] bankruptcyRecordBeans) {
        this.bankruptcyRecordBeans = bankruptcyRecordBeans;
    }

    public EvictionRecordBean[] getEvictionRecordBeans() {
        return evictionRecordBeans;
    }

    public void setEvictionRecordBeans(EvictionRecordBean[] evictionRecordBeans) {
        this.evictionRecordBeans = evictionRecordBeans;
    }

    public ArrayList<RentalRecordBean> getCurrentRental() {
        return currentRental;
    }

    public void setCurrentRental(ArrayList<RentalRecordBean> currentRental) {
        this.currentRental = currentRental;
    }

    public ArrayList<RentalRecordBean> getPreviousRental() {
        return previousRental;
    }

    public void setPreviousRental(ArrayList<RentalRecordBean> previousRental) {
        this.previousRental = previousRental;
    }
    
    public String getFirstInitial()
    {
        if (this.firstName.length() > 0)
            return "" + firstName.charAt(0);
        
        return "";
    }
    
    public boolean getHasEmploymentRecords ()
    {
        return (this.previousEmployments.size() > 0 || this.currentEmployments.size() > 0);
    }
    
    public boolean getHasRentalRecords ()
    {
        return (this.previousRental.size() > 0 || this.currentRental.size() > 0);
    }

    public DmvRecordBean[] getDmvRecordBeans() {
        return dmvRecordBeans;
    }

    public void setDmvRecordBeans(DmvRecordBean[] dmvRecordBeans) {
        this.dmvRecordBeans = dmvRecordBeans;
    }
    
}
