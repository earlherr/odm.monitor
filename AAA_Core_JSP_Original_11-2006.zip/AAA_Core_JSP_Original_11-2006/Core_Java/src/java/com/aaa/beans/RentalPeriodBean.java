/*
 * RentalPeriodBean.java
 *
 * Created on July 16, 2006, 10:26 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class RentalPeriodBean
{
    private Integer rentalPeriodId;

    private String rentalPeriodDefinition;
    
    /** Creates a new instance of RentalPeriodBean */
    public RentalPeriodBean ()
    {
    }

    public Integer getRentalPeriodId ()
    {
        return rentalPeriodId;
    }

    public void setRentalPeriodId (Integer rentalPeriodId)
    {
        this.rentalPeriodId = rentalPeriodId;
    }

    public String getRentalPeriodDefinition ()
    {
        return rentalPeriodDefinition;
    }

    public void setRentalPeriodDefinition (String rentalPeriodDefinition)
    {
        this.rentalPeriodDefinition = rentalPeriodDefinition;
    }
    
}
