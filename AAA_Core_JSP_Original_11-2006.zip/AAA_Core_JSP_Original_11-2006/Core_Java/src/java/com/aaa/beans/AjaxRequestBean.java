/*
 * AjaxRequestBean.java
 *
 * Created on July 21, 2006, 1:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author mansari
 */
public class AjaxRequestBean {
    
    
    
    
    private String RequestType = "";
    
    private Object Data;
    
    /** Creates a new instance of AjaxRequestBean */
    public AjaxRequestBean() {
    }

    public String getRequestType() {
        return RequestType;
    }

    public void setRequestType(String RequestType) {
        this.RequestType = RequestType;
    }

    public Object getData() {
        return Data;
    }

    public void setData(Object Data) {
        this.Data = Data;
    }
    
}
