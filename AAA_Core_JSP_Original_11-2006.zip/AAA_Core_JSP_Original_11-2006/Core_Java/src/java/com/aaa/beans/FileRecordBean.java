/*
 * FileRecordBean.java
 *
 * Created on November 14, 2006, 10:36 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.sql.Timestamp;

/**
 *
 * @author mansari
 */
public class FileRecordBean {
    
    private Integer fileRecordId;

    private String fileName;

    private byte[] data;

    private String webFileType;

    private Integer fileRecordTypeId;

    private String description;

    private long fileByteSize = 0;
    
    private Timestamp dateTimeCreated = new Timestamp (System.currentTimeMillis());

    private Timestamp dateTimeUpdated = new Timestamp (System.currentTimeMillis());
        
    /** Creates a new instance of FileRecordBean */
    public FileRecordBean() {
    }

    public Integer getFileRecordId() {
        return fileRecordId;
    }

    public void setFileRecordId(Integer fileRecordId) {
        this.fileRecordId = fileRecordId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public String getWebFileType() {
        return webFileType;
    }

    public void setWebFileType(String webFileType) {
        this.webFileType = webFileType;
    }

    public Integer getFileRecordTypeId() {
        return fileRecordTypeId;
    }

    public void setFileRecordTypeId(Integer fileRecordTypeId) {
        this.fileRecordTypeId = fileRecordTypeId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Timestamp getDateTimeCreated() {
        return dateTimeCreated;
    }

    public void setDateTimeCreated(Timestamp dateTimeCreated) {
        this.dateTimeCreated = dateTimeCreated;
    }

    public Timestamp getDateTimeUpdated() {
        return dateTimeUpdated;
    }

    public void setDateTimeUpdated(Timestamp dateTimeUpdated) {
        this.dateTimeUpdated = dateTimeUpdated;
    }

    public long getFileByteSize() {
        return fileByteSize;
    }

    public void setFileByteSize(long fileByteSize) {
        this.fileByteSize = fileByteSize;
    }
    
}
