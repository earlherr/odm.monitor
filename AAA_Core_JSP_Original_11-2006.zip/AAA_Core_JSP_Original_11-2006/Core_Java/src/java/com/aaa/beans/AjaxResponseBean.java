/*
 * AjaxResponseBean.java
 *
 * Created on July 23, 2006, 11:16 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class AjaxResponseBean
{
    public static final String SUCCESS = "success";
    public static final String FAIL = "fail";
    
    private String responseStatus;
    private String responseMessage;
    
    /** Creates a new instance of AjaxResponseBean */
    public AjaxResponseBean ()
    {
    }

    public String getResponseStatus ()
    {
        return responseStatus;
    }

    public void setResponseStatus (String responseStatus)
    {
        this.responseStatus = responseStatus;
    }

    public String getResponseMessage ()
    {
        return responseMessage;
    }

    public void setResponseMessage (String responseMessage)
    {
        this.responseMessage = responseMessage;
    }
    
}
