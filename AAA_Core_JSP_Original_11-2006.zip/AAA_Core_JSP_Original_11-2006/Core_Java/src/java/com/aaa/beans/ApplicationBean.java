/*
 * ApplicationBean.java
 *
 * Created on June 14, 2006, 2:36 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Mohammed Ansari
 */
public class ApplicationBean
{
    
    private Integer applicationId;

    private Integer clientId;
    
    private String propertyName;

    private Date creationDate;
    
    private Date completedDate;

    private String applicationName;
    
    private ApplicantBean[] applicantBeans = new ApplicantBean[0];
    
    private Double applicationFee;
    
    private ApplicantBean selectedApplicant = new ApplicantBean();
    
    private ClientCustomNoteBean[] clientCustomNoteBeans = new ClientCustomNoteBean[0];
    
    private Integer applicationTypeId = new Integer (1); 
        
    private Integer applicationStatusId = new Integer (1);

    private Boolean clientNotified = new Boolean (false);
    
    private Double totalApplicationIncome;
        
    private Double totalRentAmount;
    
    private String clientComments;
    
    private String unitNumber;
    
    private ApplicationScoreRecordBean applicationScoreRecordBean;
    
    /** Creates a new instance of ApplicationBean */
    public ApplicationBean()
    {
    }

    public Integer getApplicationId()
    {
        return applicationId;
    }

    public void setApplicationId(Integer applicationId)
    {
        this.applicationId = applicationId;
    }

    public Integer getClientId()
    {
        return clientId;
    }

    public void setClientId(Integer clientId)
    {
        this.clientId = clientId;
    }

    public Date getCreationDate()
    {
        return creationDate;
    }

    public void setCreationDate(Date creationDate)
    {
        this.creationDate = creationDate;
    }

    public String getApplicationName()
    {
        return applicationName;
    }

    public void setApplicationName(String applicationName)
    {
        this.applicationName = applicationName;
    }

    public ApplicantBean[] getApplicantBeans()
    {
        return applicantBeans;
    }

    public void setApplicantBeans(ApplicantBean[] applicantBeans)
    {
        if (applicantBeans != null && applicantBeans.length > 0 && getSelectedApplicant().getApplicantId() == null)
        {
            this.applicantBeans = applicantBeans;
            setSelectedApplicant(applicantBeans [0]);
        }
    }

    public String getApplicationLabel ()
    {
        SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
        return getApplicationName() + " (" + formatter.format(getCreationDate()) + ")";
    }

    public Double getApplicationFee() {
        return applicationFee;
    }

    public void setApplicationFee(Double applicationFee) {
        this.applicationFee = applicationFee;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public ApplicantBean getSelectedApplicant() {
        return selectedApplicant;
    }

    public void setSelectedApplicant(ApplicantBean selectedApplicant) {
        this.selectedApplicant = selectedApplicant;
    }
    
    public void setSelectedApplicantById(Integer id) {
        if (id != null && applicantBeans != null && applicantBeans.length > 0)
        {
            boolean found = false;
            
            for (int i = 0; i < applicantBeans.length; i++)
            {
                if (applicantBeans[i].getApplicantId() != null && applicantBeans[i].getApplicantId().intValue() == id.intValue())
                {
                    selectedApplicant = applicantBeans[i];
                    found = true;
                }
                
            }
            
            if (!found)
            {
                setSelectedApplicant(applicantBeans [0]);
            }
        }
    }
    
    public int getNumberOfApplicants ()
    {
        if (applicantBeans.length > 0)
            return applicantBeans.length;
        else 
            return 0;
    }
    
    public int getNumberOfApplicantsCompleted()
    {
        int completed = 0;
        if (applicantBeans.length > 0)
        {
            
            for (int i = 0; i < applicantBeans.length; i++)
            {
                if (applicantBeans[i].getApplicantCompleted().booleanValue())
                {
                    completed++;
                }
            }
        }
        return completed;
    }
    
    public boolean getAllApplicantsCompleted()
    {
        if (applicantBeans != null && applicantBeans.length > 0)
        {
            if (getNumberOfApplicants () == getNumberOfApplicantsCompleted())
                return true;
            else
                return false;
        }
        else
            return false;
    }
    
    public ClientCustomNoteBean[] getClientCustomNoteBeans()
    {
        return clientCustomNoteBeans;
    }

    public void setClientCustomNoteBeans(ClientCustomNoteBean[] clientCustomNoteBeans)
    {
        this.clientCustomNoteBeans = clientCustomNoteBeans;
    }

    public Integer getApplicationTypeId ()
    {
        return applicationTypeId;
    }

    public void setApplicationTypeId (Integer applicationTypeId)
    {
        this.applicationTypeId = applicationTypeId;
    }

    public Integer getApplicationStatusId ()
    {
        return applicationStatusId;
    }

    public void setApplicationStatusId (Integer applicationStatusId)
    {
        this.applicationStatusId = applicationStatusId;
    }

    public Boolean getClientNotified ()
    {
        return clientNotified;
    }

    public void setClientNotified (Boolean clientNotified)
    {
        this.clientNotified = clientNotified;
    }

    public Double getTotalApplicationIncome() {
        return totalApplicationIncome;
    }

    public void setTotalApplicationIncome(Double totalApplicationIncome) {
        this.totalApplicationIncome = totalApplicationIncome;
    }

    public Double getTotalRentAmount() {
        return totalRentAmount;
    }

    public void setTotalRentAmount(Double totalRentAmount) {
        this.totalRentAmount = totalRentAmount;
    }

    public String getClientComments ()
    {
        if (clientComments == null || clientComments.equals(""))
            return "None";
        else
            return clientComments;
    }

    public void setClientComments (String clientComments)
    {
        this.clientComments = clientComments;
    }

    public Date getCompletedDate ()
    {
        return completedDate;
    }

    public void setCompletedDate (Date completedDate)
    {
        this.completedDate = completedDate;
    }

    public ApplicationScoreRecordBean getApplicationScoreRecordBean ()
    {
        return applicationScoreRecordBean;
    }

    public void setApplicationScoreRecordBean (ApplicationScoreRecordBean applicationScoreRecordBean)
    {
        this.applicationScoreRecordBean = applicationScoreRecordBean;
    }

    public String getUnitNumber() {
        return unitNumber;
    }

    public void setUnitNumber(String unitNumber) {
        this.unitNumber = unitNumber;
    }
}
