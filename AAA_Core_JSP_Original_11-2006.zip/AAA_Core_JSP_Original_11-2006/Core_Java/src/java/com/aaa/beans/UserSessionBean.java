/*
 * UserSessionBean.java
 *
 * Created on May 21, 2006, 2:41 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.text.DateFormat;
import java.util.Locale;

/**
 *
 * @author Mohammed Ansari
 */
public class UserSessionBean 
{
    private String FirstName;
    private String LastName;
    private String Username = "";
    private String Password = "";
    private String FormattedDate = "";
    
    private String AdminMenuSelection = "-1";
    private String AdminSubMenuSelection = "-1";
    
    private String selectedClientInfoTab = "";
    
    private String selectedApplicationInfoTab = "";
    
    private String onLoadJavaScriptFunction = "";
    
    private Integer UserTypeId;
    
    private String SelectedTopMenuLink = "";
    
    private String reportsMenuSelection = "";
    private String reportsSubMenuSelection = "";
    
    /** Creates a new instance of UserSessionBean */
    public UserSessionBean() 
    {
        java.util.Date today = new java.util.Date();
	DateFormat formatter; 
	formatter = DateFormat.getDateInstance(DateFormat.LONG , Locale.US);
        setFormattedDate(formatter.format(today)); 
    }
   
    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getFormattedDate() {
        return FormattedDate;
    }

    public void setFormattedDate(String FormattedDate) {
        this.FormattedDate = FormattedDate;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getAdminMenuSelection() {
        return AdminMenuSelection;
    }

    public void setAdminMenuSelection(String AdminMenuSelection) {
        this.AdminMenuSelection = AdminMenuSelection;
    }

    public String getAdminSubMenuSelection() {
        return AdminSubMenuSelection;
    }

    public void setAdminSubMenuSelection(String AdminSubMenuSelection) {
        this.AdminSubMenuSelection = AdminSubMenuSelection;
    }

    public String getSelectedClientInfoTab() {
        return selectedClientInfoTab;
    }

    public void setSelectedClientInfoTab(String selectedClientInfoTab) {
        this.selectedClientInfoTab = selectedClientInfoTab;
    }

    public String getSelectedApplicationInfoTab() {
        return selectedApplicationInfoTab;
    }

    public void setSelectedApplicationInfoTab(String selectedApplicationInfoTab) {
        this.selectedApplicationInfoTab = selectedApplicationInfoTab;
    }

    public String getOnLoadJavaScriptFunction() {
        return onLoadJavaScriptFunction;
    }

    public void setOnLoadJavaScriptFunction(String onLoadJavaScriptFunction) {
        this.onLoadJavaScriptFunction = onLoadJavaScriptFunction;
    }
    
    public boolean hasRole(Integer roleId)
    {
        if (roleId.intValue() == this.UserTypeId.intValue())
            return true;
        else
            return false;
    }

    public Integer getUserTypeId() {
        return UserTypeId;
    }

    public void setUserTypeId(Integer UserTypeId) {
        this.UserTypeId = UserTypeId;
    }

    public String getSelectedTopMenuLink() {
        return SelectedTopMenuLink;
    }

    public void setSelectedTopMenuLink(String SelectedTopMenuLink) {
        this.SelectedTopMenuLink = SelectedTopMenuLink;
    }

    public String getReportsMenuSelection ()
    {
        return reportsMenuSelection;
    }

    public void setReportsMenuSelection (String reportsMenuSelection)
    {
        this.reportsMenuSelection = reportsMenuSelection;
    }

    public String getReportsSubMenuSelection ()
    {
        return reportsSubMenuSelection;
    }

    public void setReportsSubMenuSelection (String reportsSubMenuSelection)
    {
        this.reportsSubMenuSelection = reportsSubMenuSelection;
    }
    
}
