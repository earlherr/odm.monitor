/*
 * UserSearchManagementBean.java
 *
 * Created on June 30, 2006, 11:33 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author mansari
 */
public class UserSearchManagementBean {
    
    public static final int FIRST_NAME = 0;
    public static final int LAST_NAME = 1;
    
    private String SearchString = "";
    private int SearchCriteria = 0;
    
    private int ResultsBeginIndex = 0;
    private int ResultsEndIndex = 0;
    
    private ShallowUserInfoBean[] searchResults = null;
    
    private int MaxResults = 25;
    
    private boolean HasMoreResultsPending = true;
    
    /** Creates a new instance of UserSearchManagementBean */
    public UserSearchManagementBean() {
    }

    public String getSearchString() {
        return SearchString;
    }

    public void setSearchString(String SearchString) {
        this.SearchString = SearchString;
    }

    public int getSearchCriteria() {
        return SearchCriteria;
    }

    public void setSearchCriteria(int SearchCriteria) {
        this.SearchCriteria = SearchCriteria;
    }

    public int getResultsBeginIndex() {
        return ResultsBeginIndex;
    }

    public void setResultsBeginIndex(int ResultsBeginIndex) {
        this.ResultsBeginIndex = ResultsBeginIndex;
    }

    public int getResultsEndIndex() {
        return ResultsEndIndex;
    }

    public void setResultsEndIndex(int ResultsEndIndex) {
        this.ResultsEndIndex = ResultsEndIndex;
    }

    public ShallowUserInfoBean[] getSearchResults() {
        return searchResults;
    }

    public void setSearchResults(ShallowUserInfoBean[] searchResults) {
        this.searchResults = searchResults;
    }

    public int getMaxResults() {
        return MaxResults;
    }

    public void setMaxResults(int MaxResults) {
        this.MaxResults = MaxResults;
    }

    public boolean getHasMoreResultsPending() {
        return HasMoreResultsPending;
    }

    public void setHasMoreResultsPending(boolean HasMoreResultsPending) {
        this.HasMoreResultsPending = HasMoreResultsPending;
    }
    
}
