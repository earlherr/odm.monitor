/*
 * AutoDenyCategoryBean.java
 *
 * Created on July 3, 2006, 3:45 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author mansari
 */
public class AutoDenyCategoryBean {
    
    private Integer autoDenyCategoryId;

    private String categoryDefintion;
    
    /** Creates a new instance of AutoDenyCategoryBean */
    public AutoDenyCategoryBean() {
    }

    public Integer getAutoDenyCategoryId() {
        return autoDenyCategoryId;
    }

    public void setAutoDenyCategoryId(Integer autoDenyCategoryId) {
        this.autoDenyCategoryId = autoDenyCategoryId;
    }

    public String getCategoryDefintion() {
        return categoryDefintion;
    }

    public void setCategoryDefintion(String categoryDefintion) {
        this.categoryDefintion = categoryDefintion;
    }
    
}
