/*
 * BankruptcyRecordBean.java
 *
 * Created on July 30, 2006, 11:01 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Mohammed Ansari
 */
public class BankruptcyRecordBean
{
    private Integer bankruptcyRecordId;

    private Integer applicantId;

    private Boolean occurredWithinSevenYears = new Boolean(false);

    private Date dateFiled;
    
    private String bankruptcyDateFiledString = "";
    
    /** Creates a new instance of BankruptcyRecordBean */
    public BankruptcyRecordBean ()
    {
    }

    // Property accessors
    public Integer getBankruptcyRecordId() {
            return this.bankruptcyRecordId;
    }

    public void setBankruptcyRecordId(Integer bankruptcyRecordId) {
            this.bankruptcyRecordId = bankruptcyRecordId;
    }

    public Date getDateFiled() {
            return this.dateFiled;
    }

    public void setDateFiled(Date dateFiled) {
            this.dateFiled = dateFiled;
            
        if (dateFiled != null)
        {
            try
            {
                SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

                this.bankruptcyDateFiledString = formatter.format (dateFiled);
            }
            catch (Exception e)
            {

            }
        }
    }

    public Integer getApplicantId ()
    {
    return applicantId;
    }

    public void setApplicantId (Integer applicantId)
    {
    this.applicantId = applicantId;
    }

    public Boolean getOccurredWithinSevenYears() {
        return occurredWithinSevenYears;
    }

    public void setOccurredWithinSevenYears(Boolean occurredWithinSevenYears) {
        this.occurredWithinSevenYears = occurredWithinSevenYears;
    }

    public String getBankruptcyDateFiledString() {
        return bankruptcyDateFiledString;
    }

    public void setBankruptcyDateFiledString(String bankruptcyDateFiledString) {
        this.bankruptcyDateFiledString = bankruptcyDateFiledString;
    }
    
}
