/*
 * DmvRecordBean.java
 *
 * Created on October 30, 2006, 10:04 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author mansari
 */
public class DmvRecordBean {
    
    private Integer dmvRecordId;
        
    private Integer applicantId;

    private String charge;

    private String status;

    private Date chargeDate;

    private String dmvComment;
    
    private String chargeDateString;
        
    /** Creates a new instance of DmvRecordBean */
    public DmvRecordBean() {
    }

    public Integer getDmvRecordId() {
        return dmvRecordId;
    }

    public void setDmvRecordId(Integer dmvRecordId) {
        this.dmvRecordId = dmvRecordId;
    }

    public Integer getApplicantId() {
        return applicantId;
    }

    public void setApplicantId(Integer applicantId) {
        this.applicantId = applicantId;
    }

    public String getCharge() {
        return charge;
    }

    public void setCharge(String charge) {
        this.charge = charge;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getChargeDate() {
        return chargeDate;
    }

    public void setChargeDate(Date chargeDate) {
        this.chargeDate = chargeDate;
        
        
        
        try
        {
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

            chargeDateString = (formatter.format(chargeDate));
        }
        catch (Exception e)
        {
            
        }
        
    }

    public String getDmvComment() {
        return dmvComment;
    }

    public void setDmvComment(String dmvComment) {
        this.dmvComment = dmvComment;
    }

    public String getChargeDateString() {
        return chargeDateString;
    }

    public void setChargeDateString(String chargeDateString) {
        this.chargeDateString = chargeDateString;
    }
    
}
