/*
 * YearBean.java
 *
 * Created on September 16, 2006, 7:10 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class YearBean
{
    private Integer yearId;

    private String year;

    private String yearAbbreviation;
        
    /** Creates a new instance of YearBean */
    public YearBean ()
    {
    }

    public Integer getYearId ()
    {
        return yearId;
    }

    public void setYearId (Integer yearId)
    {
        this.yearId = yearId;
    }

    public String getYear ()
    {
        return year;
    }

    public void setYear (String year)
    {
        this.year = year;
    }

    public String getYearAbbreviation ()
    {
        return yearAbbreviation;
    }

    public void setYearAbbreviation (String yearAbbreviation)
    {
        this.yearAbbreviation = yearAbbreviation;
    }
    
}
