/*
 * CriminalRecordBean.java
 *
 * Created on July 21, 2006, 2:28 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author mansari
 */
public class CriminalRecordBean {
    
    public static final int FELONY = 1;
    public static final int MISDEMEANOR = 1;
    
    private Integer criminalRecordId;

    private Integer criminalInfoId;

    private String criminalCharge;

    private String chargeDateString;
    
    private Date chargeDate;

    private String chargeStatus;

    private Boolean occurredWithinFiveYears = new Boolean (false);

    private Integer criminalOffenseTypeId;
    
    private String courtLocation;
        
    /** Creates a new instance of CriminalRecordBean */
    public CriminalRecordBean() {
    }

    public Integer getCriminalRecordId() {
        return criminalRecordId;
    }

    public void setCriminalRecordId(Integer criminalRecordId) {
        this.criminalRecordId = criminalRecordId;
    }

    public Integer getCriminalInfoId() {
        return criminalInfoId;
    }

    public void setCriminalInfoId(Integer criminalInfoId) {
        this.criminalInfoId = criminalInfoId;
    }

    public String getCriminalCharge() {
        return criminalCharge;
    }

    public void setCriminalCharge(String criminalCharge) {
        this.criminalCharge = criminalCharge;
    }

    public String getChargeDateString() {
        return chargeDateString;
    }

    public void setChargeDateString(String chargeDateString) {
        this.chargeDateString = chargeDateString;
        
        
            
    }

    public String getChargeStatus() {
        return chargeStatus;
    }

    public void setChargeStatus(String chargeStatus) {
        this.chargeStatus = chargeStatus;
    }

    public Boolean getOccurredWithinFiveYears ()
    {
        return occurredWithinFiveYears;
    }

    public void setOccurredWithinFiveYears (Boolean occurredWithinFiveYears)
    {
        this.occurredWithinFiveYears = occurredWithinFiveYears;
    }

    public Integer getCriminalOffenseTypeId ()
    {
        return criminalOffenseTypeId;
    }

    public void setCriminalOffenseTypeId (Integer criminalOffenseTypeId)
    {
        this.criminalOffenseTypeId = criminalOffenseTypeId;
    }

    public Date getChargeDate ()
    {
        return chargeDate;
    }

    public void setChargeDate (Date chargeDate)
    {
        this.chargeDate = chargeDate;
        if (chargeDate != null)
        {
            try
            {
                SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

                this.chargeDateString = formatter.format (chargeDate);
            }
            catch (Exception e)
            {

            }
        }
    }
    
    public String getOffenseTypeString ()
    {
        if (this.criminalOffenseTypeId.intValue() == this.FELONY)
            return "Felony";
        else
            return "Misdemeanor";
    }

    public String getCourtLocation() {
        return courtLocation;
    }

    public void setCourtLocation(String courtLocation) {
        this.courtLocation = courtLocation;
    }
    
}
