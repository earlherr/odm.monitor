/*
 * ShallowClientInfoBean.java
 *
 * Created on June 13, 2006, 3:42 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.util.List;

/**
 *
 * @author Mohammed Ansari
 */
public class ShallowClientInfoBean
{
    
    private Integer clientId = null;
    
    private String addressLine1;
    
    private String city;
    
    private String stateCode;
    
    private String zipCode;
    
    private String homePhoneNumber;
    
    private String faxPhoneNumber;
    
    private String email;

    private String propertyName = "";
    
    private String propertyManagementCompanyName = "";
    
    private Integer propertyManagementCompanyId = null;
    
    //this is what gets displayed in result table ie 'July - 2006'
    private String invoiceMonthYearString;
    
    //this is the id representation ie '072006'
    private String invoiceMonthYearId;
    
    private List<ShallowApplicationBean> shallowApplications;
    
    public ShallowClientInfoBean()
    {
    }

    public Integer getClientId()
    {
        return clientId;
    }

    public void setClientId(Integer clientId)
    {
        this.clientId = clientId;
    }

    public String getPropertyName()
    {
        return propertyName;
    }

    public void setPropertyName(String propertyName)
    {
        this.propertyName = propertyName;
    }

    public String getHomePhoneNumber()
    {
        if (homePhoneNumber == (null) || homePhoneNumber.equals(""))
            return "none specified";
        else
            return homePhoneNumber;
    }

    public void setHomePhoneNumber(String homePhoneNumber)
    {
        this.homePhoneNumber = homePhoneNumber;
    }

    public String getEmail()
    {
        if (email == (null) || email.equals(""))
            return "none specified";
        else
            return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getPropertyManagementCompanyName()
    {
        if (propertyManagementCompanyName == (null) || propertyManagementCompanyName.equals(""))
            return "none specified";
        else
            return propertyManagementCompanyName;
    }

    public void setPropertyManagementCompanyName(String propertyManagementCompanyName)
    {
        this.propertyManagementCompanyName = propertyManagementCompanyName;
    }

    public Integer getPropertyManagementCompanyId()
    {
        return propertyManagementCompanyId;
    }

    public void setPropertyManagementCompanyId(Integer propertyManagementCompanyId)
    {
        this.propertyManagementCompanyId = propertyManagementCompanyId;
    }

    public List<ShallowApplicationBean> getShallowApplications ()
    {
        return shallowApplications;
    }

    public void setShallowApplications (List<ShallowApplicationBean> shallowApplications)
    {
        this.shallowApplications = shallowApplications;
    }

    public String getInvoiceMonthYearString ()
    {
        return invoiceMonthYearString;
    }

    public void setInvoiceMonthYearString (String invoiceMonthYearString)
    {
        this.invoiceMonthYearString = invoiceMonthYearString;
    }

    public String getInvoiceMonthYearId ()
    {
        return invoiceMonthYearId;
    }

    public void setInvoiceMonthYearId (String invoiceMonthYearId)
    {
        this.invoiceMonthYearId = invoiceMonthYearId;
    }

    public String getCity ()
    {
        return city;
    }

    public void setCity (String city)
    {
        this.city = city;
    }

    public String getStateCode ()
    {
        return stateCode;
    }

    public void setStateCode (String stateCode)
    {
        this.stateCode = stateCode;
    }

    public String getZipCode ()
    {
        return zipCode;
    }

    public void setZipCode (String zipCode)
    {
        this.zipCode = zipCode;
    }

    public String getFaxPhoneNumber ()
    {
        return faxPhoneNumber;
    }

    public void setFaxPhoneNumber (String faxPhoneNumber)
    {
        this.faxPhoneNumber = faxPhoneNumber;
    }

    public String getAddressLine1 ()
    {
        return addressLine1;
    }

    public void setAddressLine1 (String addressLine1)
    {
        this.addressLine1 = addressLine1;
    }
    
}
