/*
 * PayPeriodBean.java
 *
 * Created on July 10, 2006, 11:45 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class PayPeriodBean
{
    private Integer payPeriodId;

    private String payPeriodDefinition;
    
    /** Creates a new instance of PayPeriodBean */
    public PayPeriodBean()
    {
    }

    public Integer getPayPeriodId()
    {
        return payPeriodId;
    }

    public void setPayPeriodId(Integer payPeriodId)
    {
        this.payPeriodId = payPeriodId;
    }

    public String getPayPeriodDefinition()
    {
        return payPeriodDefinition;
    }

    public void setPayPeriodDefinition(String payPeriodDefinition)
    {
        this.payPeriodDefinition = payPeriodDefinition;
    }
    
}
