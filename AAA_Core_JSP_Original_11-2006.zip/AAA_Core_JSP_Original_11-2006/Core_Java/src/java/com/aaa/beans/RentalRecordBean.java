/*
 * RentalRecordBean.java
 *
 * Created on July 20, 2006, 10:55 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import com.aaa.dao.entity.ContactInfo;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 *
 * @author mansari
 */
public class RentalRecordBean {
    
    private Integer rentalRecordId;

    private Integer applicantId;

    private Integer rentalPeriodId;

    

    private String landlordName;

    private Date moveInDate;

    private Date moveOutDate;

    private Boolean vacateNoticeGiven;

    private Boolean havePets;

    private String verifiedBy;

    private Double rentAmount;

    private Integer numberOfLatePays;

    private Integer numberOfNsfChecks;

    private Integer numberOfEvictions;

    private Integer numberOfNoticesServed;

    private Boolean willRerent;

    private String landlordComments;
    
    /* Contact info */
    private Integer contactInfoId;

    private String stateCode;

    private String addressLine1;

    private String addressLine2;

    private String addressLine3;

    private String city;

    private String zipCode;

    private String homePhoneNumber;

    private String mobilePhoneNumber;

    private String faxPhoneNumber;

    private String email;
    
    private String moveInDateString;

    private String moveOutDateString;
    
    private String leaseExpirationDateString;
    
    private Date leaseExpirationDate;
    
    private Boolean stillLivingOnProperty = new Boolean (false);
    
    private String stillLivingOnPropertyString = "No";

    public Integer getRentalRecordId() {
        return rentalRecordId;
    }

    public void setRentalRecordId(Integer rentalRecordId) {
        this.rentalRecordId = rentalRecordId;
    }

    public Integer getApplicantId() {
        return applicantId;
    }

    public void setApplicantId(Integer applicantId) {
        this.applicantId = applicantId;
    }

    public Integer getRentalPeriodId() {
        return rentalPeriodId;
    }

    public void setRentalPeriodId(Integer rentalPeriodId) {
        this.rentalPeriodId = rentalPeriodId;
    }

    public String getLandlordName() {
        return landlordName;
    }

    public void setLandlordName(String landlordName) {
        this.landlordName = landlordName;
    }

    public Date getMoveInDate() {
        return moveInDate;
    }

    public void setMoveInDate(Date moveInDate) {
        this.moveInDate = moveInDate;
        
        try
        {
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

            this.setMoveInDateString(formatter.format(moveInDate));
        }
        catch (Exception e)
        {
            
        }
    }

    public Date getMoveOutDate() {
        return moveOutDate;
    }

    public void setMoveOutDate(Date moveOutDate) {
        this.moveOutDate = moveOutDate;
        
         try
        {
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

            this.setMoveOutDateString(formatter.format(moveOutDate));
        }
        catch (Exception e)
        {
            
        }
    }

    public Boolean getVacateNoticeGiven() {
        return vacateNoticeGiven;
    }

    public void setVacateNoticeGiven(Boolean vacateNoticeGiven) {
        this.vacateNoticeGiven = vacateNoticeGiven;
    }

    public Boolean getHavePets() {
        return havePets;
    }

    public void setHavePets(Boolean havePets) {
        this.havePets = havePets;
    }

    public String getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(String verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public Double getRentAmount() {
        return rentAmount;
    }

    public void setRentAmount(Double rentAmount) {
        this.rentAmount = rentAmount;
    }

    public Integer getNumberOfLatePays() {
        return numberOfLatePays;
    }

    public void setNumberOfLatePays(Integer numberOfLatePays) {
        this.numberOfLatePays = numberOfLatePays;
    }

    public Integer getNumberOfNsfChecks() {
        return numberOfNsfChecks;
    }

    public void setNumberOfNsfChecks(Integer numberOfNsfChecks) {
        this.numberOfNsfChecks = numberOfNsfChecks;
    }

    public Integer getNumberOfEvictions() {
        return numberOfEvictions;
    }

    public void setNumberOfEvictions(Integer numberOfEvictions) {
        this.numberOfEvictions = numberOfEvictions;
    }

    public Integer getNumberOfNoticesServed() {
        return numberOfNoticesServed;
    }

    public void setNumberOfNoticesServed(Integer numberOfNoticesServed) {
        this.numberOfNoticesServed = numberOfNoticesServed;
    }

    public Boolean getWillRerent() {
        return willRerent;
    }

    public void setWillRerent(Boolean willRerent) {
        this.willRerent = willRerent;
    }

    public String getLandlordComments() {
        return landlordComments;
    }

    public void setLandlordComments(String landlordComments) {
        this.landlordComments = landlordComments;
    }

    public Integer getContactInfoId() {
        return contactInfoId;
    }

    public void setContactInfoId(Integer contactInfoId) {
        this.contactInfoId = contactInfoId;
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getHomePhoneNumber() {
        return homePhoneNumber;
    }

    public void setHomePhoneNumber(String homePhoneNumber) {
        this.homePhoneNumber = homePhoneNumber;
    }

    public String getMobilePhoneNumber() {
        return mobilePhoneNumber;
    }

    public void setMobilePhoneNumber(String mobilePhoneNumber) {
        this.mobilePhoneNumber = mobilePhoneNumber;
    }

    public String getFaxPhoneNumber() {
        return faxPhoneNumber;
    }

    public void setFaxPhoneNumber(String faxPhoneNumber) {
        this.faxPhoneNumber = faxPhoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMoveInDateString() {
        return moveInDateString;
    }

    public void setMoveInDateString(String moveInDateString) {
        this.moveInDateString = moveInDateString;
    }

    public String getMoveOutDateString() {
        return moveOutDateString;
    }

    public void setMoveOutDateString(String moveOutDateString) {
        this.moveOutDateString = moveOutDateString;
    }

    public String getLeaseExpirationDateString ()
    {
        return leaseExpirationDateString;
    }

    public void setLeaseExpirationDateString (String leaseExpirationDateString)
    {
        this.leaseExpirationDateString = leaseExpirationDateString;
    }

    public Date getLeaseExpirationDate ()
    {
        return leaseExpirationDate;
    }

    public void setLeaseExpirationDate (Date leaseExpirationDate)
    {
        this.leaseExpirationDate = leaseExpirationDate;
        
        try
        {
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

            leaseExpirationDateString = (formatter.format(leaseExpirationDate));
        }
        catch (Exception e)
        {
            
        }
    }

    public Boolean getStillLivingOnProperty ()
    {
        return stillLivingOnProperty;
    }

    public void setStillLivingOnProperty (Boolean stillLivingOnProperty)
    {
        this.stillLivingOnProperty = stillLivingOnProperty;
    }

    public String getStillLivingOnPropertyString ()
    {
        if (stillLivingOnProperty)
            return "Yes";
        else
            return "No";
    }

    public void setStillLivingOnPropertyString (String stillLivingOnPropertyString)
    {
        this.stillLivingOnPropertyString = stillLivingOnPropertyString;
    }
    
    
    
}
