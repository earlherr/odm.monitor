/*
 * EvictionRecordBean.java
 *
 * Created on July 24, 2006, 3:22 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author mansari
 */
public class EvictionRecordBean {
    
    private Integer evictionRecordId;

    private Integer applicantId;

    private Date evictionDate;
    
    private String evictionDateString;

    private String evictionCourt;

    private String evictionStatus;
    
    private String addressOfEviction;
        
    private String plantiffName;
    
    private Boolean occurredWithinThreeYears = new Boolean (false);
    
    /** Creates a new instance of EvictionRecordBean */
    public EvictionRecordBean() {
    }

    public Integer getEvictionRecordId() {
        return evictionRecordId;
    }

    public void setEvictionRecordId(Integer evictionRecordId) {
        this.evictionRecordId = evictionRecordId;
    }

    public Integer getApplicantId() {
        return applicantId;
    }

    public void setApplicantId(Integer applicantId) {
        this.applicantId = applicantId;
    }

    public Date getEvictionDate() {
        return evictionDate;
    }

    public void setEvictionDate(Date evictionDate) {
        this.evictionDate = evictionDate;
        
         
        if (evictionDate != null)
        {
            try
            {
                SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

                this.evictionDateString = formatter.format (evictionDate);
            }
            catch (Exception e)
            {

            }
        }
    }

    public String getEvictionDateString() {
        return evictionDateString;
    }

    public void setEvictionDateString(String evictionDateString) {
        this.evictionDateString = evictionDateString;
    }

    public String getEvictionCourt() {
        return evictionCourt;
    }

    public void setEvictionCourt(String evictionCourt) {
        this.evictionCourt = evictionCourt;
    }

    public String getEvictionStatus() {
        return evictionStatus;
    }

    public void setEvictionStatus(String evictionStatus) {
        this.evictionStatus = evictionStatus;
    }

    public Boolean getOccurredWithinThreeYears ()
    {
        return occurredWithinThreeYears;
    }

    public void setOccurredWithinThreeYears (Boolean occurredWithinThreeYears)
    {
        this.occurredWithinThreeYears = occurredWithinThreeYears;
    }

    public String getAddressOfEviction() {
        return addressOfEviction;
    }

    public void setAddressOfEviction(String addressOfEviction) {
        this.addressOfEviction = addressOfEviction;
    }

    public String getPlantiffName() {
        return plantiffName;
    }

    public void setPlantiffName(String plantiffName) {
        this.plantiffName = plantiffName;
    }
    
}
