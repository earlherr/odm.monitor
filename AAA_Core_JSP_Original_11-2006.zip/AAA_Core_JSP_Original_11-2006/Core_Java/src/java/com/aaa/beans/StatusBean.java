/*
 * StatusBean.java
 *
 * Created on June 18, 2006, 7:47 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class StatusBean
{
    
    private Integer statusId;

    private String statusDefinition;
        
    /** Creates a new instance of StatusBean */
    public StatusBean()
    {
    }

    public Integer getStatusId()
    {
        return statusId;
    }

    public void setStatusId(Integer statusId)
    {
        this.statusId = statusId;
    }

    public String getStatusDefinition()
    {
        return statusDefinition;
    }

    public void setStatusDefinition(String statusDefinition)
    {
        this.statusDefinition = statusDefinition;
    }
    
}
