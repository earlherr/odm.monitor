/*
 * WorkTimeTypeBean.java
 *
 * Created on July 10, 2006, 11:46 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class WorkTimeTypeBean
{
    private Integer workTimeTypeId;

    private String workTimeTypeDefinition;
        
    /** Creates a new instance of WorkTimeTypeBean */
    public WorkTimeTypeBean()
    {
    }

    public Integer getWorkTimeTypeId()
    {
        return workTimeTypeId;
    }

    public void setWorkTimeTypeId(Integer workTimeTypeId)
    {
        this.workTimeTypeId = workTimeTypeId;
    }

    public String getWorkTimeTypeDefinition()
    {
        return workTimeTypeDefinition;
    }

    public void setWorkTimeTypeDefinition(String workTimeTypeDefinition)
    {
        this.workTimeTypeDefinition = workTimeTypeDefinition;
    }
    
}
