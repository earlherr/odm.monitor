/*
 * SelectedAutoDenyCriteriaBean.java
 *
 * Created on July 5, 2006, 3:11 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author mansari
 */
public class SelectedAutoDenyCriteriaBean {
    
    private Integer selectedAutoDenyCriteriaId;

    private Integer clientId;

    private Integer autoDenyCriteriaId;
    
    private String criteriaStatement;
    
    private Integer autoDenyCategoryId;
    
        
    /** Creates a new instance of SelectedAutoDenyCriteriaBean */
    public SelectedAutoDenyCriteriaBean() {
    }

    public Integer getSelectedAutoDenyCriteriaId() {
        return selectedAutoDenyCriteriaId;
    }

    public void setSelectedAutoDenyCriteriaId(Integer selectedAutoDenyCriteriaId) {
        this.selectedAutoDenyCriteriaId = selectedAutoDenyCriteriaId;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public Integer getAutoDenyCriteriaId() {
        return autoDenyCriteriaId;
    }

    public void setAutoDenyCriteriaId(Integer autoDenyCriteriaId) {
        this.autoDenyCriteriaId = autoDenyCriteriaId;
    }

    public String getCriteriaStatement()
    {
        return criteriaStatement;
    }

    public void setCriteriaStatement(String criteriaStatement)
    {
        this.criteriaStatement = criteriaStatement;
    }

    public Integer getAutoDenyCategoryId() {
        return autoDenyCategoryId;
    }

    public void setAutoDenyCategoryId(Integer autoDenyCategoryId) {
        this.autoDenyCategoryId = autoDenyCategoryId;
    }
    
}
