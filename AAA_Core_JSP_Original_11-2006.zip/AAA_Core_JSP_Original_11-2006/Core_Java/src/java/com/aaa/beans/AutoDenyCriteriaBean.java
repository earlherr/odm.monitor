/*
 * AutoDenyCriteriaBean.java
 *
 * Created on July 3, 2006, 3:09 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author mansari
 */
public class AutoDenyCriteriaBean {
    
    private Integer autoDenyCriteriaId;

    private Integer autoDenyCategoryId;

    private String criteriaStatement;
    
    /** Creates a new instance of AutoDenyCriteriaBean */
    public AutoDenyCriteriaBean() {
    }

    public Integer getAutoDenyCriteriaId() {
        return autoDenyCriteriaId;
    }

    public void setAutoDenyCriteriaId(Integer autoDenyCriteriaId) {
        this.autoDenyCriteriaId = autoDenyCriteriaId;
    }

    public Integer getAutoDenyCategoryId() {
        return autoDenyCategoryId;
    }

    public void setAutoDenyCategoryId(Integer autoDenyCategoryId) {
        this.autoDenyCategoryId = autoDenyCategoryId;
    }

    public String getCriteriaStatement() {
        return criteriaStatement;
    }

    public void setCriteriaStatement(String criteriaStatement) {
        this.criteriaStatement = criteriaStatement;
    }
    
}
