/*
 * ApplicationCriteriaBean.java
 *
 * Created on June 14, 2006, 10:28 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class ApplicationDecisionStatementBean
{
    private Integer decisionStatementId;
    
    private Integer clientId;
    
    private String statement;
    
    private Integer high;
    
    private Integer low;
    
    /** Creates a new instance of ApplicationCriteriaBean */
    public ApplicationDecisionStatementBean()
    {
    }

    public Integer getDecisionStatementId()
    {
        return decisionStatementId;
    }

    public void setDecisionStatementId(Integer decisionStatementId)
    {
        this.decisionStatementId = decisionStatementId;
    }

    public Integer getClientId()
    {
        return clientId;
    }

    public void setClientId(Integer clientId)
    {
        this.clientId = clientId;
    }

    public String getStatement()
    {
        return statement;
    }

    public void setStatement(String statement)
    {
        this.statement = statement;
    }

    public Integer getHigh()
    {
        return high;
    }

    public void setHigh(Integer high)
    {
        this.high = high;
    }

    public Integer getLow()
    {
        return low;
    }

    public void setLow(Integer low)
    {
        this.low = low;
    }
    
}
