/*
 * MonthBean.java
 *
 * Created on September 16, 2006, 7:11 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class MonthBean
{
    private Integer monthId;

    private String monthName;

    private String monthAbbreviation;
        
    /** Creates a new instance of MonthBean */
    public MonthBean ()
    {
    }

    public Integer getMonthId ()
    {
        return monthId;
    }

    public void setMonthId (Integer monthId)
    {
        this.monthId = monthId;
    }

    public String getMonthName ()
    {
        return monthName;
    }

    public void setMonthName (String monthName)
    {
        this.monthName = monthName;
    }

    public String getMonthAbbreviation ()
    {
        return monthAbbreviation;
    }

    public void setMonthAbbreviation (String monthAbbreviation)
    {
        this.monthAbbreviation = monthAbbreviation;
    }
    
}
