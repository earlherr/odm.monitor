/*
 * PaymentTypeBean.java
 *
 * Created on September 16, 2006, 7:12 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class PaymentTypeBean
{
    private Integer paymentTypeId;

    private String paymentTypeDescription;
    
    /** Creates a new instance of PaymentTypeBean */
    public PaymentTypeBean ()
    {
    }

    public Integer getPaymentTypeId ()
    {
        return paymentTypeId;
    }

    public void setPaymentTypeId (Integer paymentTypeId)
    {
        this.paymentTypeId = paymentTypeId;
    }

    public String getPaymentTypeDescription ()
    {
        return paymentTypeDescription;
    }

    public void setPaymentTypeDescription (String paymentTypeDescription)
    {
        this.paymentTypeDescription = paymentTypeDescription;
    }
    
}
