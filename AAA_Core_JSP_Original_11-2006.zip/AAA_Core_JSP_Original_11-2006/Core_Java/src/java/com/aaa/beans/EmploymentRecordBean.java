/*
 * EmploymentRecordBean.java
 *
 * Created on July 11, 2006, 12:16 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Mohammed Ansari
 */
public class EmploymentRecordBean
{
    
    private Integer employmentRecordId;

    private Integer contactInfoId;

    private Integer applicantId;

    private Integer workTimeTypeId;

    private Integer payPeriodId;

    

    private String employerName;

    private Date dateHired;
    
    private String dateHiredString;

    private Date dateEnded;
    
    private String dateEndedString;

    private String jobTitle;

    private Boolean isStillEmployed = new Boolean (false);

    private Boolean willEmployerRehire = new Boolean (true);

    private String tasks;

    private String reasonForLeaving;

    private String awardsAndRecognition;

    private String performanceRating;

    private String employerComments;
        
    private Double wage;
    
    private String homePhoneNumber;
    
    private String faxPhoneNumber;
    
    private String propertyPhoneNumber;
    
    /** Creates a new instance of EmploymentRecordBean */
    public EmploymentRecordBean()
    {
    }

    public Integer getEmploymentRecordId()
    {
        return employmentRecordId;
    }

    public void setEmploymentRecordId(Integer employmentRecordId)
    {
        this.employmentRecordId = employmentRecordId;
    }

    public Integer getContactInfoId()
    {
        return contactInfoId;
    }

    public void setContactInfoId(Integer contactInfoId)
    {
        this.contactInfoId = contactInfoId;
    }

    public Integer getApplicantId()
    {
        return applicantId;
    }

    public void setApplicantId(Integer applicantId)
    {
        this.applicantId = applicantId;
    }

    public Integer getWorkTimeTypeId()
    {
        return workTimeTypeId;
    }

    public void setWorkTimeTypeId(Integer workTimeTypeId)
    {
        this.workTimeTypeId = workTimeTypeId;
    }

    public Integer getPayPeriodId()
    {
        return payPeriodId;
    }

    public void setPayPeriodId(Integer payPeriodId)
    {
        this.payPeriodId = payPeriodId;
    }

    

    public String getEmployerName()
    {
        return employerName;
    }

    public void setEmployerName(String employerName)
    {
        this.employerName = employerName;
    }

    public Date getDateHired() {
        return dateHired;
    }

    public void setDateHired(Date dateHired)
    {
        this.dateHired = dateHired;
        
        try
        {
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

            setDateHiredString(formatter.format(dateHired));
        }
        catch (Exception e)
        {
            
        }
    }

    public Date getDateEnded() {
        return dateEnded;
    }

    public void setDateEnded(Date dateEnded) {
        this.dateEnded = dateEnded;
        
        try
        {
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

            setDateEndedString(formatter.format(dateEnded));
        }
        catch (Exception e)
        {
            
        }
    }

    public String getJobTitle()
    {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle)
    {
        this.jobTitle = jobTitle;
    }

    public Boolean getIsStillEmployed()
    {
        return isStillEmployed;
    }

    public void setIsStillEmployed(Boolean isStillEmployed)
    {
        this.isStillEmployed = isStillEmployed;
    }

    public Boolean getWillEmployerRehire()
    {
        return willEmployerRehire;
    }

    public void setWillEmployerRehire(Boolean willEmployerRehire)
    {
        this.willEmployerRehire = willEmployerRehire;
    }

    public String getTasks()
    {
        return tasks;
    }

    public void setTasks(String tasks)
    {
        this.tasks = tasks;
    }

    public String getReasonForLeaving()
    {
        return reasonForLeaving;
    }

    public void setReasonForLeaving(String reasonForLeaving)
    {
        this.reasonForLeaving = reasonForLeaving;
    }

    public String getAwardsAndRecognition()
    {
        return awardsAndRecognition;
    }

    public void setAwardsAndRecognition(String awardsAndRecognition)
    {
        this.awardsAndRecognition = awardsAndRecognition;
    }

    public String getPerformanceRating()
    {
        return performanceRating;
    }

    public void setPerformanceRating(String performanceRating)
    {
        this.performanceRating = performanceRating;
    }

    public String getEmployerComments()
    {
        return employerComments;
    }

    public void setEmployerComments(String employerComments)
    {
        this.employerComments = employerComments;
    }

    public String getDateEndedString() {
        return dateEndedString;
    }

    public void setDateEndedString(String dateEndedString) {
        this.dateEndedString = dateEndedString;
    }

    public String getDateHiredString() {
        return dateHiredString;
    }

    public void setDateHiredString(String dateHiredString) {
        this.dateHiredString = dateHiredString;
    }

    public Double getWage ()
    {
        return wage;
    }

    public void setWage (Double wage)
    {
        this.wage = wage;
    }

    public String getHomePhoneNumber ()
    {
        return homePhoneNumber;
    }

    public void setHomePhoneNumber (String homePhoneNumber)
    {
        this.homePhoneNumber = homePhoneNumber;
    }

    public String getPropertyPhoneNumber ()
    {
        return propertyPhoneNumber;
    }

    public void setPropertyPhoneNumber (String propertyPhoneNumber)
    {
        this.propertyPhoneNumber = propertyPhoneNumber;
    }

    public String getFaxPhoneNumber ()
    {
        return faxPhoneNumber;
    }

    public void setFaxPhoneNumber (String faxPhoneNumber)
    {
        this.faxPhoneNumber = faxPhoneNumber;
    }
    
}
