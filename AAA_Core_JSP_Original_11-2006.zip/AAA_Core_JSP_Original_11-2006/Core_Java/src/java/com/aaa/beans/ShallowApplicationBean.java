/*
 * ShallowApplicationBean.java
 *
 * Created on September 16, 2006, 11:29 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Mohammed Ansari
 */
public class ShallowApplicationBean
{
    private Integer applicationId;
    
    private String applicationName;
    
    private Timestamp creationDateTime;
    
    private Integer clientId;
    
    private Double applicationFee;
    
    private List<ShallowApplicantBean> shallowApplicantBeans = new ArrayList ();
    
    /** Creates a new instance of ShallowApplicationBean */
    public ShallowApplicationBean ()
    {
    }

    public Integer getApplicationId ()
    {
        return applicationId;
    }

    public void setApplicationId (Integer applicationId)
    {
        this.applicationId = applicationId;
    }

    public String getApplicationName ()
    {
        return applicationName;
    }

    public void setApplicationName (String applicationName)
    {
        this.applicationName = applicationName;
    }

    public List<ShallowApplicantBean> getShallowApplicantBeans ()
    {
        return shallowApplicantBeans;
    }

    public void setShallowApplicantBeans (List<ShallowApplicantBean> shallowApplicantBeans)
    {
        this.shallowApplicantBeans = shallowApplicantBeans;
    }

    public Timestamp getCreationDateTime ()
    {
        return creationDateTime;
    }

    public void setCreationDateTime (Timestamp creationDateTime)
    {
        this.creationDateTime = creationDateTime;
    }

    public Integer getClientId ()
    {
        return clientId;
    }

    public void setClientId (Integer clientId)
    {
        this.clientId = clientId;
    }

    public Double getApplicationFee ()
    {
        return applicationFee;
    }

    public void setApplicationFee (Double applicationFee)
    {
        this.applicationFee = applicationFee;
    }
    
}
