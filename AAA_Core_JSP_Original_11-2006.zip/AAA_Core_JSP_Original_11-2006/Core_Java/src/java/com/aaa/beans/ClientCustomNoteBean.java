/*
 * ClientCustomNoteBean.java
 *
 * Created on June 25, 2006, 12:19 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class ClientCustomNoteBean
{
    private Integer customNoteId;

    private Integer clientId;

    private String customNote;
                
    /** Creates a new instance of ClientCustomNoteBean */
    public ClientCustomNoteBean()
    {
    }

    public Integer getCustomNoteId()
    {
        return customNoteId;
    }

    public void setCustomNoteId(Integer customNoteId)
    {
        this.customNoteId = customNoteId;
    }

    public Integer getClientId()
    {
        return clientId;
    }

    public void setClientId(Integer clientId)
    {
        this.clientId = clientId;
    }

    public String getCustomNote()
    {
        return customNote;
    }

    public void setCustomNote(String customNote)
    {
        this.customNote = customNote;
    }
    
}
