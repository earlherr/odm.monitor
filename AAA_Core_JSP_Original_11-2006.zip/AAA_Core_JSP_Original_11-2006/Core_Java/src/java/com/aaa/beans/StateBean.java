/*
 * StateBean.java
 *
 * Created on May 28, 2006, 7:10 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class StateBean {
    
    private String stateCode = "AZ";;

    private String stateName;
        
    /** Creates a new instance of StateBean */
    public StateBean() {
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }
    
}
