/*
 * ApplicationTypeBean.java
 *
 * Created on July 16, 2006, 6:02 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class ApplicationTypeBean
{
    private Integer applicationTypeId;

    private String applicationTypeDefinition;
        
    /** Creates a new instance of ApplicationTypeBean */
    public ApplicationTypeBean ()
    {
    }

    public Integer getApplicationTypeId ()
    {
        return applicationTypeId;
    }

    public void setApplicationTypeId (Integer applicationTypeId)
    {
        this.applicationTypeId = applicationTypeId;
    }

    public String getApplicationTypeDefinition ()
    {
        return applicationTypeDefinition;
    }

    public void setApplicationTypeDefinition (String applicationDefinition)
    {
        this.applicationTypeDefinition = applicationDefinition;
    }
    
}
