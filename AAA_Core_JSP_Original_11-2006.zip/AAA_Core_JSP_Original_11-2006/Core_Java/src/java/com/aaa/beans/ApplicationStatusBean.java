/*
 * ApplicationStatusBean.java
 *
 * Created on July 16, 2006, 6:03 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class ApplicationStatusBean
{
    private Integer applicationStatusId;

    private String applicationStatusDefinition;

        
    /** Creates a new instance of ApplicationStatusBean */
    public ApplicationStatusBean ()
    {
    }

    public Integer getApplicationStatusId ()
    {
        return applicationStatusId;
    }

    public void setApplicationStatusId (Integer applicationStatusId)
    {
        this.applicationStatusId = applicationStatusId;
    }

    public String getApplicationStatusDefinition ()
    {
        return applicationStatusDefinition;
    }

    public void setApplicationStatusDefinition (String applicationStatusDefinition)
    {
        this.applicationStatusDefinition = applicationStatusDefinition;
    }
    
}
