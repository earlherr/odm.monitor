/*
 * UserTypeBean.java
 *
 * Created on May 28, 2006, 7:10 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class UserTypeBean 
{
    
    // Fields
    private Integer userTypeId;

    private String userTypeDefinition;
        
    /** Creates a new instance of UserTypeBean */
    public UserTypeBean() 
    {
    }

    public Integer getUserTypeId() {
        return userTypeId;
    }

    public void setUserTypeId(Integer userTypeId) {
        this.userTypeId = userTypeId;
    }

    public String getUserTypeDefinition() {
        return userTypeDefinition;
    }

    public void setUserTypeDefinition(String userTypeDefinition) {
        this.userTypeDefinition = userTypeDefinition;
    }
    
}
