/*
 * CreditCardTypeBean.java
 *
 * Created on September 16, 2006, 7:11 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class CreditCardTypeBean
{
    private Integer creditCardTypeId;

    private String creditCardTypeDescription;
        
    /** Creates a new instance of CreditCardTypeBean */
    public CreditCardTypeBean ()
    {
    }

    public Integer getCreditCardTypeId ()
    {
        return creditCardTypeId;
    }

    public void setCreditCardTypeId (Integer creditCardTypeId)
    {
        this.creditCardTypeId = creditCardTypeId;
    }

    public String getCreditCardTypeDescription ()
    {
        return creditCardTypeDescription;
    }

    public void setCreditCardTypeDescription (String creditCardTypeDescription)
    {
        this.creditCardTypeDescription = creditCardTypeDescription;
    }
    
}
