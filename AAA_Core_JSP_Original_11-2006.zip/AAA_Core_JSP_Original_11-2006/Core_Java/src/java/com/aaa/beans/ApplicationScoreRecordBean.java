/*
 * ScoredApplicationBean.java
 *
 * Created on July 26, 2006, 9:02 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 *
 * @author Mohammed Ansari
 */
public class ApplicationScoreRecordBean
{
    
    public static final int RENTAL_APPLICATION = 1;
    public static final int EMPLOYMENT_APPLICATION = 2;
    
    private Integer applicationScoreRecordId;
    
    private int FinalScore = 0;
    
    
    private int TotalScoreableApplicants = 0;
    
    private int TotalEvictionsUnderThreeYears = 0;
    private int TotalEvictionsOverThreeYears = 0;
    private int TotalBankruptcyUnderThreeYears = 0;
    private int TotalBankruptcyOverThreeYears = 0;
    private int TotalFelonyOverFiveYears = 0;
    private int TotalFelonyUnderFiveYears = 0;
    private int TotalMisdemeanorOverFiveYears = 0;
    private int TotalMisdemeanorUnderFiveYears = 0;
    private int TotalPendingWarrant = 0;
            
            
    private int TotalFelonyOverFiveDeduction = 0;
    private int TotalFelonyUnderFiveDeduction = 0;
    private int TotalMisdemeanorOverFiveDeduction = 0;
    private int TotalMisdemeanorUnderFiveDeduction = 0;
    private int TotalEvictionOverThreeDeduction = 0;
    private int TotalEvictionUnderThreeDeduction = 0;
    private int TotalBankruptcyOverThreeDeduction = 0; 
    private int TotalBankruptcyUnderThreeDeduction = 0;
            
    private int TotalFelonyDeduction = 0;
    private int TotalMisdemeanorDeduction = 0;
    private int TotalEvictionDeduction = 0;
    private int TotalBankruptcyDeduction = 0;
    private int TotalPendingWarrantDeduction = 0;
    
    private int TotalPositiveCredit = 0;
    private int TotalNegativeCredit = 0;
    private int TotalCollections = 0;
    private int TotalJudgements = 0;
    private int CombinedFicoScore = 0;
    
    private double CombinedMonthlyIncome = 0;
    private double ProjectedRent = 0;
    private double combinedRentIncomeRatio = 0;
    
    private int IncomeRatioDeduction = 0;
    
    private String ClientSpecifiedComment = "";
    
    private String SystemGeneratedComment = "";
        
    private int verdictScore = 0;
    
    private boolean ApplicationDenied = false;
    
    private String decisionStatement = null;
    
    /** Creates a new instance of ScoredApplicationBean */
    public ApplicationScoreRecordBean ()
    {
    }

    public int getFinalScore ()
    {
        return FinalScore;
    }

    public void setFinalScore (int FinalScore)
    {
        this.FinalScore = FinalScore;
    }

    public int getTotalScoreableApplicants ()
    {
        return TotalScoreableApplicants;
    }

    public void setTotalScoreableApplicants (int TotalScoreableApplicants)
    {
        this.TotalScoreableApplicants = TotalScoreableApplicants;
    }

    public int getTotalFelonyDeduction ()
    {
        return TotalFelonyDeduction;
    }

    public void setTotalFelonyDeduction (int TotalFelonyDeduction)
    {
        this.TotalFelonyDeduction = TotalFelonyDeduction;
    }

    public int getTotalMisdemeanorDeduction ()
    {
        return TotalMisdemeanorDeduction;
    }

    public void setTotalMisdemeanorDeduction (int TotalMisdemeanorDeduction)
    {
        this.TotalMisdemeanorDeduction = TotalMisdemeanorDeduction;
    }

    public int getTotalEvictionDeduction ()
    {
        return TotalEvictionDeduction;
    }

    public void setTotalEvictionDeduction (int TotalEvictionDeduction)
    {
        this.TotalEvictionDeduction = TotalEvictionDeduction;
    }

    public int getTotalBankruptcyDeduction ()
    {
        return TotalBankruptcyDeduction;
    }

    public void setTotalBankruptcyDeduction (int TotalBankruptcyDeduction)
    {
        this.TotalBankruptcyDeduction = TotalBankruptcyDeduction;
    }

    public int getTotalPendingWarrantDeduction ()
    {
        return TotalPendingWarrantDeduction;
    }

    public void setTotalPendingWarrantDeduction (int TotalPendingWarrantDeduction)
    {
        this.TotalPendingWarrantDeduction = TotalPendingWarrantDeduction;
    }

    public int getTotalPositiveCredit ()
    {
        return TotalPositiveCredit;
    }

    public void setTotalPositiveCredit (int TotalPositiveCredit)
    {
        this.TotalPositiveCredit = TotalPositiveCredit;
    }

    public int getTotalNegativeCredit ()
    {
        return TotalNegativeCredit;
    }

    public void setTotalNegativeCredit (int TotalNegativeCredit)
    {
        this.TotalNegativeCredit = TotalNegativeCredit;
    }

    public int getTotalCollections ()
    {
        return TotalCollections;
    }

    public void setTotalCollections (int TotalCollections)
    {
        this.TotalCollections = TotalCollections;
    }

    public int getTotalJudgements ()
    {
        return TotalJudgements;
    }

    public void setTotalJudgements (int TotalJudgements)
    {
        this.TotalJudgements = TotalJudgements;
    }

    public int getCombinedFicoScore ()
    {
        return CombinedFicoScore;
    }

    public void setCombinedFicoScore (int CombinedFicoScore)
    {
        this.CombinedFicoScore = CombinedFicoScore;
    }

    public double getCombinedMonthlyIncome ()
    {
        return CombinedMonthlyIncome;
    }

    public void setCombinedMonthlyIncome (double CombinedMonthlyIncome)
    {
        this.CombinedMonthlyIncome = CombinedMonthlyIncome;
    }

    public double getProjectedRent ()
    {
        return ProjectedRent;
    }

    public void setProjectedRent (double ProjectedRent)
    {
        this.ProjectedRent = ProjectedRent;
    }

    public String getClientSpecifiedComment ()
    {
        return ClientSpecifiedComment;
    }

    public void setClientSpecifiedComment (String ClientSpecifiedComment)
    {
        this.ClientSpecifiedComment = ClientSpecifiedComment;
    }

    public String getSystemGeneratedComment ()
    {
        return SystemGeneratedComment;
    }

    public void setSystemGeneratedComment (String SystemGeneratedComment)
    {
        this.SystemGeneratedComment = SystemGeneratedComment;
    }

    public int getTotalEvictionsUnderThreeYears ()
    {
        return TotalEvictionsUnderThreeYears;
    }

    public void setTotalEvictionsUnderThreeYears (int TotalEvictionsUnderThreeYears)
    {
        this.TotalEvictionsUnderThreeYears = TotalEvictionsUnderThreeYears;
    }

    public int getTotalEvictionsOverThreeYears ()
    {
        return TotalEvictionsOverThreeYears;
    }

    public void setTotalEvictionsOverThreeYears (int TotalEvictionsOverThreeYears)
    {
        this.TotalEvictionsOverThreeYears = TotalEvictionsOverThreeYears;
    }

    public int getTotalBankruptcyUnderThreeYears ()
    {
        return TotalBankruptcyUnderThreeYears;
    }

    public void setTotalBankruptcyUnderThreeYears (int TotalBankruptcyUnderThreeYears)
    {
        this.TotalBankruptcyUnderThreeYears = TotalBankruptcyUnderThreeYears;
    }

    public int getTotalBankruptcyOverThreeYears ()
    {
        return TotalBankruptcyOverThreeYears;
    }

    public void setTotalBankruptcyOverThreeYears (int TotalBankruptcyOverThreeYears)
    {
        this.TotalBankruptcyOverThreeYears = TotalBankruptcyOverThreeYears;
    }

    public int getTotalFelonyOverFiveYears ()
    {
        return TotalFelonyOverFiveYears;
    }

    public void setTotalFelonyOverFiveYears (int TotalFelonyOverFiveYears)
    {
        this.TotalFelonyOverFiveYears = TotalFelonyOverFiveYears;
    }

    public int getTotalFelonyUnderFiveYears ()
    {
        return TotalFelonyUnderFiveYears;
    }

    public void setTotalFelonyUnderFiveYears (int TotalFelonyUnderFiveYears)
    {
        this.TotalFelonyUnderFiveYears = TotalFelonyUnderFiveYears;
    }

    public int getTotalMisdemeanorOverFiveYears ()
    {
        return TotalMisdemeanorOverFiveYears;
    }

    public void setTotalMisdemeanorOverFiveYears (int TotalMisdemeanorOverFiveYears)
    {
        this.TotalMisdemeanorOverFiveYears = TotalMisdemeanorOverFiveYears;
    }

    public int getTotalMisdemeanorUnderFiveYears ()
    {
        return TotalMisdemeanorUnderFiveYears;
    }

    public void setTotalMisdemeanorUnderFiveYears (int TotalMisdemeanorUnderFiveYears)
    {
        this.TotalMisdemeanorUnderFiveYears = TotalMisdemeanorUnderFiveYears;
    }

    public int getTotalFelonyOverFiveDeduction ()
    {
        return TotalFelonyOverFiveDeduction;
    }

    public void setTotalFelonyOverFiveDeduction (int TotalFelonyOverFiveDeduction)
    {
        this.TotalFelonyOverFiveDeduction = TotalFelonyOverFiveDeduction;
    }

    public int getTotalFelonyUnderFiveDeduction ()
    {
        return TotalFelonyUnderFiveDeduction;
    }

    public void setTotalFelonyUnderFiveDeduction (int TotalFelonyUnderFiveDeduction)
    {
        this.TotalFelonyUnderFiveDeduction = TotalFelonyUnderFiveDeduction;
    }

    public int getTotalMisdemeanorOverFiveDeduction ()
    {
        return TotalMisdemeanorOverFiveDeduction;
    }

    public void setTotalMisdemeanorOverFiveDeduction (int TotalMisdemeanorOverFiveDeduction)
    {
        this.TotalMisdemeanorOverFiveDeduction = TotalMisdemeanorOverFiveDeduction;
    }

    public int getTotalMisdemeanorUnderFiveDeduction ()
    {
        return TotalMisdemeanorUnderFiveDeduction;
    }

    public void setTotalMisdemeanorUnderFiveDeduction (int TotalMisdemeanorUnderFiveDeduction)
    {
        this.TotalMisdemeanorUnderFiveDeduction = TotalMisdemeanorUnderFiveDeduction;
    }

    public int getTotalEvictionOverThreeDeduction ()
    {
        return TotalEvictionOverThreeDeduction;
    }

    public void setTotalEvictionOverThreeDeduction (int TotalEvictionOverThreeDeduction)
    {
        this.TotalEvictionOverThreeDeduction = TotalEvictionOverThreeDeduction;
    }

    public int getTotalEvictionUnderThreeDeduction ()
    {
        return TotalEvictionUnderThreeDeduction;
    }

    public void setTotalEvictionUnderThreeDeduction (int TotalEvictionUnderThreeDeduction)
    {
        this.TotalEvictionUnderThreeDeduction = TotalEvictionUnderThreeDeduction;
    }

    public int getTotalBankruptcyOverThreeDeduction ()
    {
        return TotalBankruptcyOverThreeDeduction;
    }

    public void setTotalBankruptcyOverThreeDeduction (int TotalBankruptcyOverThreeDeduction)
    {
        this.TotalBankruptcyOverThreeDeduction = TotalBankruptcyOverThreeDeduction;
    }

    public int getTotalBankruptcyUnderThreeDeduction ()
    {
        return TotalBankruptcyUnderThreeDeduction;
    }

    public void setTotalBankruptcyUnderThreeDeduction (int TotalBankruptcyUnderThreeDeduction)
    {
        this.TotalBankruptcyUnderThreeDeduction = TotalBankruptcyUnderThreeDeduction;
    }

    public int getTotalPendingWarrant ()
    {
        return TotalPendingWarrant;
    }

    public void setTotalPendingWarrant (int TotalPendingWarrant)
    {
        this.TotalPendingWarrant = TotalPendingWarrant;
    }
    
    public int getTotalCreditDeduction ()
    {
        
        return TotalEvictionDeduction + TotalBankruptcyDeduction;
    }
    
     public int getTotalCriminalDeduction ()
    {
        
        return  TotalFelonyDeduction + TotalMisdemeanorDeduction +  TotalPendingWarrantDeduction;
    }

    public int getIncomeRatioDeduction ()
    {
        return IncomeRatioDeduction;
    }

    public void setIncomeRatioDeduction (int IncomeRatioDeduction)
    {
        this.IncomeRatioDeduction = IncomeRatioDeduction;
    }

    public Integer getApplicationScoreRecordId ()
    {
        return applicationScoreRecordId;
    }

    public void setApplicationScoreRecordId (Integer applicationScoreRecordId)
    {
        this.applicationScoreRecordId = applicationScoreRecordId;
    }
    
    public int getTotalVerdictScore()
    {
        //if deduction happening on ratio, we want to add it to total verdict score, so we minus
        
        return (getTotalCriminalDeduction() + getTotalCreditDeduction() + getIncomeRatioDeduction());
    }

    public double getCombinedRentIncomeRatio() {
        return combinedRentIncomeRatio;
    }

    public void setCombinedRentIncomeRatio(double combinedRentIncomeRatio) {
        this.combinedRentIncomeRatio = combinedRentIncomeRatio;
    }

    public int getVerdictScore() {
        return verdictScore;
    }

    public void setVerdictScore(int verdictScore) {
        this.verdictScore = verdictScore;
    }

    public String getHasBankruptcyString ()
    {
        if (this.TotalBankruptcyUnderThreeYears > 0)
            return "Yes";
        else
            return "No";
    }

    public String getCombinedMonthlyIncomeString() 
    {
        NumberFormat formatter = new DecimalFormat("#.##");
        String s = "$" + formatter.format(CombinedMonthlyIncome);
    
        return s;
    }
    
    public String getProjectedRentString()
    {
        NumberFormat formatter = new DecimalFormat("#.##");
        String s = "$" + formatter.format(ProjectedRent);
    
        return s;
    }

    public boolean getApplicationDenied() {
        return ApplicationDenied;
    }

    public void setApplicationDenied(boolean ApplicationDenied) {
        this.ApplicationDenied = ApplicationDenied;
    }

    public String getDecisionStatement ()
    {
        return decisionStatement;
    }

    public void setDecisionStatement (String decisionStatement)
    {
        this.decisionStatement = decisionStatement;
    }
    
}
