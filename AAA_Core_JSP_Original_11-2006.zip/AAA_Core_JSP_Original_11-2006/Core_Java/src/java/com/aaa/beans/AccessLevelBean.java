/*
 * AccessLevelBean.java
 *
 * Created on June 18, 2006, 7:46 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class AccessLevelBean
{
    
    private Integer accessLevelId;

    private String accessLevelDefinition;
    
    /** Creates a new instance of AccessLevelBean */
    public AccessLevelBean()
    {
    }

    public Integer getAccessLevelId()
    {
        return accessLevelId;
    }

    public void setAccessLevelId(Integer accessLevelId)
    {
        this.accessLevelId = accessLevelId;
    }

    public String getAccessLevelDefinition()
    {
        return accessLevelDefinition;
    }

    public void setAccessLevelDefinition(String accessLevelDefinition)
    {
        this.accessLevelDefinition = accessLevelDefinition;
    }
    
}
