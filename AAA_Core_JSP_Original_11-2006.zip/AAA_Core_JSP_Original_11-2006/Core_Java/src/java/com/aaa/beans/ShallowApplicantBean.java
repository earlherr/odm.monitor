/*
 * ShallowApplicantBean.java
 *
 * Created on July 30, 2006, 1:49 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.util.Date;

/**
 *
 * @author Ansari
 */
public class ShallowApplicantBean {
    
    private String FirstName = "";
    private String LastName = "";
    
    private Integer ApplicantId;
    private Integer ApplicationId;
    private Date CreationDate;
    
    /** Creates a new instance of ShallowApplicantBean */
    public ShallowApplicantBean() {
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public Integer getApplicantId() {
        return ApplicantId;
    }

    public void setApplicantId(Integer ApplicantId) {
        this.ApplicantId = ApplicantId;
    }

    public Integer getApplicationId() {
        return ApplicationId;
    }

    public void setApplicationId(Integer ApplicationId) {
        this.ApplicationId = ApplicationId;
    }

    public Date getCreationDate() {
        return CreationDate;
    }

    public void setCreationDate(Date CreationDate) {
        this.CreationDate = CreationDate;
    }
    
    public String getApplicantNameLabel()
    {
        return LastName + ", " + FirstName + " - " + CreationDate;
    }
}
