/*
 * GenderBean.java
 *
 * Created on June 23, 2006, 2:11 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author mansari
 */
public class GenderBean {
    
    private Integer genderId;

    private String gender;
        
    /** Creates a new instance of GenderBean */
    public GenderBean() {
    }

    public Integer getGenderId() {
        return genderId;
    }

    public void setGenderId(Integer genderId) {
        this.genderId = genderId;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    
}
