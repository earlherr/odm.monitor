/*
 * InvoiceBean.java
 *
 * Created on September 17, 2006, 5:00 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Date;

/**
 *
 * @author Mohammed Ansari
 */
public class InvoiceBean
{
    
    private String formattedMonthYear;
    
    //private Timestamp dateTimeCreated;
    
    private String invoiceId;

    private Integer clientId;

    private Integer creditCardTypeId = null;

    private Integer paymentTypeId = null;


    private Integer numberOfApplicants = 0;

    private Integer numberOfApplications = 0;

    private Double invoiceAmount = 0d;

    private Double balanceDue = 0d;

    private Double balancePaid = 0d;

    private Integer creditCardNumber;

    private Date creditCardExpiration;

    private String checkNumber;
    
    //Client info
    private String propertyName;
    
    private String contactPersonFirstName;

    private String contactPersonLastName;
    
    private String stateCode;

    private String addressLine1;

    private String addressLine2;

    private String addressLine3;

    private String city;

    private String zipCode;

    private String homePhoneNumber;

    private String faxPhoneNumber;

    private String email;
    
    private String paymentDateString;
    
    private Date invoiceStartDate;

   
    
    /** Creates a new instance of InvoiceBean */
    public InvoiceBean ()
    {
    }

    public String getInvoiceId ()
    {
        return invoiceId;
    }

    public void setInvoiceId (String invoiceId)
    {
        this.invoiceId = invoiceId;
    }

    public Integer getClientId ()
    {
        return clientId;
    }

    public void setClientId (Integer clientId)
    {
        this.clientId = clientId;
    }

    public Integer getCreditCardTypeId ()
    {
        return creditCardTypeId;
    }

    public void setCreditCardTypeId (Integer creditCardTypeId)
    {
        this.creditCardTypeId = creditCardTypeId;
    }

    public Integer getPaymentTypeId ()
    {
        return paymentTypeId;
    }

    public void setPaymentTypeId (Integer paymentTypeId)
    {
        this.paymentTypeId = paymentTypeId;
    }

    

    public Integer getNumberOfApplicants ()
    {
        return numberOfApplicants;
    }

    public void setNumberOfApplicants (Integer numberOfApplicants)
    {
        this.numberOfApplicants = numberOfApplicants;
    }

    public Integer getNumberOfApplications ()
    {
        return numberOfApplications;
    }

    public void setNumberOfApplications (Integer numberOfApplications)
    {
        this.numberOfApplications = numberOfApplications;
    }

    public Double getInvoiceAmount ()
    {
        return invoiceAmount;
    }

    public void setInvoiceAmount (Double invoiceAmount)
    {
        this.invoiceAmount = invoiceAmount;
    }

    public Double getBalanceDue ()
    {
        return balanceDue;
    }

    public void setBalanceDue (Double balanceDue)
    {
        this.balanceDue = balanceDue;
    }

    public Double getBalancePaid ()
    {
        return balancePaid;
    }

    public void setBalancePaid (Double balancePaid)
    {
        this.balancePaid = balancePaid;
    }

    public Integer getCreditCardNumber ()
    {
        return creditCardNumber;
    }

    public void setCreditCardNumber (Integer creditCardNumber)
    {
        this.creditCardNumber = creditCardNumber;
    }

    public Date getCreditCardExpiration ()
    {
        return creditCardExpiration;
    }

    public void setCreditCardExpiration (Date creditCardExpiration)
    {
        this.creditCardExpiration = creditCardExpiration;
    }

    public String getCheckNumber ()
    {
        return checkNumber;
    }

    public void setCheckNumber (String checkNumber)
    {
        this.checkNumber = checkNumber;
    }

    public String getPropertyName ()
    {
        return propertyName;
    }

    public void setPropertyName (String propertyName)
    {
        this.propertyName = propertyName;
    }

    public String getContactPersonFirstName ()
    {
        return contactPersonFirstName;
    }

    public void setContactPersonFirstName (String contactPersonFirstName)
    {
        this.contactPersonFirstName = contactPersonFirstName;
    }

    public String getContactPersonLastName ()
    {
        return contactPersonLastName;
    }

    public void setContactPersonLastName (String contactPersonLastName)
    {
        this.contactPersonLastName = contactPersonLastName;
    }

    public String getStateCode ()
    {
        return stateCode;
    }

    public void setStateCode (String stateCode)
    {
        this.stateCode = stateCode;
    }

    public String getAddressLine1 ()
    {
        return addressLine1;
    }

    public void setAddressLine1 (String addressLine1)
    {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2 ()
    {
        return addressLine2;
    }

    public void setAddressLine2 (String addressLine2)
    {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3 ()
    {
        return addressLine3;
    }

    public void setAddressLine3 (String addressLine3)
    {
        this.addressLine3 = addressLine3;
    }

    public String getCity ()
    {
        return city;
    }

    public void setCity (String city)
    {
        this.city = city;
    }

    public String getZipCode ()
    {
        return zipCode;
    }

    public void setZipCode (String zipCode)
    {
        this.zipCode = zipCode;
    }

    public String getHomePhoneNumber ()
    {
        return homePhoneNumber;
    }

    public void setHomePhoneNumber (String homePhoneNumber)
    {
        this.homePhoneNumber = homePhoneNumber;
    }

    public String getFaxPhoneNumber ()
    {
        return faxPhoneNumber;
    }

    public void setFaxPhoneNumber (String faxPhoneNumber)
    {
        this.faxPhoneNumber = faxPhoneNumber;
    }

    public String getEmail ()
    {
        return email;
    }

    public void setEmail (String email)
    {
        this.email = email;
    }

    public String getFormattedMonthYear ()
    {
        return formattedMonthYear;
    }

    public void setFormattedMonthYear (String formattedMonthYear)
    {
        this.formattedMonthYear = formattedMonthYear;
    }

    public String getBalanceDueString ()
    {
        NumberFormat formatter = new DecimalFormat("#.##");
        String s = "$" + formatter.format(this.getBalanceDue ());
    
        return s;
    }
    
    public String getBalancePaidString ()
    {
        NumberFormat formatter = new DecimalFormat("#.##");
        String s = "$" + formatter.format(this.getBalancePaid ());
    
        return s;
    }
    
     public String getInvoiceAmountString ()
    {
        NumberFormat formatter = new DecimalFormat("#.##");
        String s = "$" + formatter.format(this.getInvoiceAmount ());
    
        return s;
    }
     
     public String getCreditCardNumberSuffix ()
     {
         if (creditCardNumber.toString ().length () >= 4)
         {
             return (creditCardNumber.toString ().substring (creditCardNumber.toString ().length () - 4, creditCardNumber.toString ().length ()));
         }
         else 
             return creditCardNumber.toString ();
     }

    public String getPaymentDateString ()
    {
        return paymentDateString;
    }

    public void setPaymentDateString (String paymentDateString)
    {
        this.paymentDateString = paymentDateString;
    }

    public Date getInvoiceStartDate() {
        return invoiceStartDate;
    }

    public void setInvoiceStartDate(Date invoiceStartDate) {
        this.invoiceStartDate = invoiceStartDate;
    }

    /*
    public Timestamp getDateTimeCreated() {
        return dateTimeCreated;
    }

    public void setDateTimeCreated(Timestamp dateTimeCreated) {
        this.dateTimeCreated = dateTimeCreated;
    }
    */
  
    
}
