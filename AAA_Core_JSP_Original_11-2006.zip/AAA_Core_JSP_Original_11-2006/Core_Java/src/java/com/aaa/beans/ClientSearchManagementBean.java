/*
 * ClientManagementBean.java
 *
 * Created on May 21, 2006, 4:23 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.beans;

/**
 *
 * @author Mohammed Ansari
 */
public class ClientSearchManagementBean {
    
    public static final int PROPERTY_NAME = 0;
    public static final int MANAGEMENT_COMPANY_NAME = 1;
    public static final int INVOICE = 2;
    
    private String SearchString = "";
    private int SearchCriteria = 0;
    
    private int ResultsBeginIndex = 0;
    private int ResultsEndIndex = 0;
    
    private ShallowClientInfoBean[] searchResults = null;
    
    private int MaxResults = 25;
    
    private boolean HasMoreResultsPending = true;
    
    private int totalResultsFound;
    
    private int fromInvoiceMonth = 1;
    private int toInvoiceMonth = 12;
    
    private int fromInvoiceYear;
    private int toInvoiceYear;
    
    /** Creates a new instance of ClientManagementBean */
    public ClientSearchManagementBean() {
    }

    public String getSearchString() {
        return SearchString;
    }

    public void setSearchString(String SearchString) {
        this.SearchString = SearchString;
    }

    public int getSearchCriteria() {
        return SearchCriteria;
    }

    public void setSearchCriteria(int SearchCriteria) {
        this.SearchCriteria = SearchCriteria;
    }

    public int getResultsBeginIndex() {
        return ResultsBeginIndex;
    }

    public void setResultsBeginIndex(int ResultsBeginIndex) {
        this.ResultsBeginIndex = ResultsBeginIndex;
    }

    public int getResultsEndIndex() {
        return ResultsEndIndex;
    }

    public void setResultsEndIndex(int ResultsEndIndex) {
        this.ResultsEndIndex = ResultsEndIndex;
    }

    public ShallowClientInfoBean[] getSearchResults()
    {
        return searchResults;
    }

    public void setSearchResults(ShallowClientInfoBean[] searchResults)
    {
        this.searchResults = searchResults;
    }

    public int getMaxResults()
    {
        return MaxResults;
    }

    public void setMaxResults(int MaxResults)
    {
        this.MaxResults = MaxResults;
    }

    public boolean getHasMoreResultsPending()
    {
        return HasMoreResultsPending;
    }

    public void setHasMoreResultsPending(boolean HasMoreResultsPending)
    {
        this.HasMoreResultsPending = HasMoreResultsPending;
    }

    public int getTotalResultsFound ()
    {
        return totalResultsFound;
    }

    public void setTotalResultsFound (int totalResultsFound)
    {
        this.totalResultsFound = totalResultsFound;
    }

    public int getFromInvoiceMonth ()
    {
        return fromInvoiceMonth;
    }

    public void setFromInvoiceMonth (int fromInvoiceMonth)
    {
        this.fromInvoiceMonth = fromInvoiceMonth;
    }

    public int getToInvoiceMonth ()
    {
        return toInvoiceMonth;
    }

    public void setToInvoiceMonth (int toInvoiceMonth)
    {
        this.toInvoiceMonth = toInvoiceMonth;
    }

    public int getFromInvoiceYear ()
    {
        return fromInvoiceYear;
    }

    public void setFromInvoiceYear (int fromInvoiceYear)
    {
        this.fromInvoiceYear = fromInvoiceYear;
    }

    public int getToInvoiceYear ()
    {
        return toInvoiceYear;
    }

    public void setToInvoiceYear (int toInvoiceYear)
    {
        this.toInvoiceYear = toInvoiceYear;
    }
    
}
