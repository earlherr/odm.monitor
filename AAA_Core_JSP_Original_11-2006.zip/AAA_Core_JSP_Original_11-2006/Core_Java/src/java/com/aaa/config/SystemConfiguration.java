/*
 * SystemConfiguration.java
 *
 * Created on September 2, 2006, 8:56 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.config;

import java.util.HashMap;

/**
 *
 * @author Mohammed Ansari
 */
public class SystemConfiguration
{
    public static final String COMPANY_NAME  = "company.name";
    public static final String COMPANY_SUB_HEADING  = "company.sub.heading";
    public static final String COMPANY_CONTACT  = "company.contact";
    public static final String COMPANY_PHONE  = "company.phone";
    public static final String COMPANY_FAX  = "company.fax";
    public static final String COMPANY_ADDRESS  = "company.address";
    public static final String COMPANY_EMAIL  = "company.email";
    public static final String INVESTIGATOR_LICENSE  = "investigator.license";
    
    private static HashMap<String, String> Configuartion = new HashMap ();
    
    /** Creates a new instance of SystemConfiguration */
    public SystemConfiguration ()
    {
    }
    
    public static void setConfigurationMap(HashMap configuration)
    {
        SystemConfiguration.Configuartion = configuration;
    }
    
    public static String getConfigurationValue (String key)
    {
        return (String) Configuartion.get (key);
    }
    
    public static HashMap getConfigurationMap ()
    {
        return SystemConfiguration.Configuartion;
    }
    
}
