/*
 * ScoringConfiguration.java
 *
 * Created on July 26, 2006, 10:09 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.config;

import java.util.HashMap;

/**
 *
 * @author Mohammed Ansari
 */
public class ScoringConfiguration
{
    public static final String BANKRUPTCY_OVER_TEN_YEARS  = "bankruptcy.gt10.deduction";
    public static final String BANKRUPTCY_UNDER_TEN_YEARS = "bankruptcy.lt10.deduction";
    public static final String EVICTION_OVER_TWO_YEARS = "eviction.gt2.deduction";
    public static final String EVICTION_UNDER_TWO_YEARS = "eviction.lt2.deduction";
    public static final String MISDEMEANOR_OVER_FIVE_YEARS = "misdemeanor.gt5.deduction";
    public static final String MISDEMEANOR_UNDER_FIVE_YEARS = "misdemeanor.lt5.deduction";;
    public static final String FELONY_OVER_FIVE_YEARS = "felony.gt5.deduction";
    public static final String FELONY_UNDER_FIVE_YEARS = "felony.lt5.deduction";
    public static final String PENDING_WARRANTS = "pending.warrants.deduction";
    
    
    private static HashMap Configuartion = new HashMap ();
    
    /** Creates a new instance of ScoringConfiguration */
    public ScoringConfiguration (HashMap configuartion)
    {
        this.Configuartion = configuartion;
    }	
    
    public static void setConfigurationMap(HashMap configuration)
    {
        ScoringConfiguration.Configuartion = configuration;
    }
    
    public static String getConfigurationValue (String key)
    {
        return (String) Configuartion.get (key);
    }
    
    public static HashMap getConfigurationMap ()
    {
        return ScoringConfiguration.Configuartion;
    }
    
}
