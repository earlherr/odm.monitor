/*
 * ApplicationDao.java
 *
 * Created on June 14, 2006, 2:39 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.Application;
import java.util.List;

/**
 *
 * @author Mohammed Ansari
 */
public interface ApplicationDao
{
    
    public Application getApplication (Integer id) throws Exception;
    
    public Application[] getAllApplicationsForClient (Integer clientId) throws Exception;
    
    public Application[] getAllApplicationForClientWithinDays(Integer clientId, int days) throws Exception;
    
    public Application saveApplication (Application entity) throws Exception;
    
    public void deleteApplication(Integer id) throws Exception;
    
    public Application updateApplication(Application entity) throws Exception;
    
    public List getAllRawShallowApplicationDataForClientWithinDays (Integer clientId, int days) throws Exception;
    
    public List getAllRawShallowApplicantDataForClientWithinDays(Integer clientId, int days) throws Exception;
    
    public List getRawApplicationDataForMonthAndYear (int month, int year) throws Exception;
    
    public List getRawApplicationDataForClientMonthAndYear (Integer clientId, int month, int year) throws Exception;
    
    public List getRawApplicationDataBeforeMonthAndYear (int month, int year) throws Exception;
    
}
