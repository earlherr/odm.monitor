/*
 * AutoDenyCategoryDao.java
 *
 * Created on July 3, 2006, 3:39 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.AutoDenyCategory;

/**
 *
 * @author mansari
 */
public interface AutoDenyCategoryDao {
    
    /** Creates a new instance of AutoDenyCategoryDao */
    public AutoDenyCategory[] getAllAutoDenyCategories() throws Exception;
    
}
