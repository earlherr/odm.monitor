/*
 * BankruptcyRecordDao.java
 *
 * Created on July 31, 2006, 11:30 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.BankruptcyRecord;

/**
 *
 * @author Ansari
 */
public interface BankruptcyRecordDao {
    
    public BankruptcyRecord saveBankruptcyRecord (BankruptcyRecord entity) throws Exception;
    
    public BankruptcyRecord updateBankruptcyRecord(BankruptcyRecord entity) throws Exception;
            
    public void deleteBankruptcyRecord (BankruptcyRecord entity) throws Exception;
    
    public BankruptcyRecord[] getBankruptcyRecordForApplicant(Integer applicantId) throws Exception;
    
    public BankruptcyRecord getBankruptcyRecord (Integer id) throws Exception;
}
