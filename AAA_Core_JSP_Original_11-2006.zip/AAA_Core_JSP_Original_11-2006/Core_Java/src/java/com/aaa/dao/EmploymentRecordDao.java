/*
 * EmploymentRecordDao.java
 *
 * Created on July 11, 2006, 1:03 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.EmploymentRecord;

/**
 *
 * @author mansari
 */
public interface EmploymentRecordDao {
    

    public EmploymentRecord saveEmploymentRecord(EmploymentRecord entity) throws Exception;
    
    public EmploymentRecord updateEmploymentRecord(EmploymentRecord entity) throws Exception;
    
    public void deleteEmploymentRecord(EmploymentRecord entity) throws Exception;
    
    public EmploymentRecord getEmploymentRecord(Integer recordId)throws Exception;
}
