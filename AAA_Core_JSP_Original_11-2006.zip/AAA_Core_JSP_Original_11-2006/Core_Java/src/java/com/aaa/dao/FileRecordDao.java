/*
 * FileSystemDao.java
 *
 * Created on November 14, 2006, 9:49 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.FileRecord;
import java.sql.Timestamp;

/**
 *
 * @author mansari
 */
public interface FileRecordDao {
    
    
    public FileRecord getFileRecord(Integer id) throws Exception;
    
    public FileRecord[] getFileRecordsWithTypeAndWithinDateRange(Integer fileRecordTypeId, Timestamp fromDate, Timestamp toDate) throws Exception;
    
    public FileRecord saveFileRecord(FileRecord fileRecord) throws Exception;
    
    public FileRecord updateFileRecord(FileRecord entity) throws Exception;
    
    public void deleteFileRecord(Integer fileRecordId) throws Exception;
    
}
