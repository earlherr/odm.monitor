/*
 * EvictionRecordDao.java
 *
 * Created on July 25, 2006, 11:29 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.EvictionRecord;

/**
 *
 * @author Mohammed Ansari
 */
public interface EvictionRecordDao
{
    
   /** Creates a new instance of CriminalInfoDao */
    public EvictionRecord saveEvictionRecord(EvictionRecord entity) throws Exception;
    
    public EvictionRecord updateEvictionRecord(EvictionRecord entity) throws Exception;
    
    public void  deleteEvictionRecord(EvictionRecord entity) throws Exception;
            
    public EvictionRecord[] getEvictionRecordForApplicant(Integer applicantId) throws Exception;

    
}
