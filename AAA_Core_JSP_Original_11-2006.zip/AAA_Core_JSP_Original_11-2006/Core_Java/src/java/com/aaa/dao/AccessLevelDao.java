/*
 * AccessLevelDao.java
 *
 * Created on June 18, 2006, 7:44 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.AccessLevel;

/**
 *
 * @author Mohammed Ansari
 */
public interface AccessLevelDao
{
    
    public AccessLevel[] getAllAccessLevels () throws Exception;
    
}
