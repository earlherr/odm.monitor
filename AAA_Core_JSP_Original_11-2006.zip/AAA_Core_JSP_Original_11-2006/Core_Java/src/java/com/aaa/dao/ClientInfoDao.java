/*
 * ClientInfoEntityDao.java
 *
 * Created on May 21, 2006, 7:56 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.AssignedClient;
import com.aaa.dao.entity.Client;
import java.util.List;
import java.util.Set;

/**
 *
 * @author Mohammed Ansari
 */
public interface ClientInfoDao 
{
    public Client[] getAllClientInfo() throws Exception; 
    
    public Client saveClientInfo(Client entity) throws Exception;
    
    public int getTotalClientsInSystem() throws Exception; 
    
    public Client[] getClientsUsingCustomSearch (String query, String searchString, int firstResultIndex, int maxResults) throws Exception;
    
    public Client getClient(Integer id) throws Exception;
    
    public Client updateClientInfo(Client entity) throws Exception;
    
    public int getTotalClientsInSystem(String query, String searchString) throws Exception;
     
    public AssignedClient saveAssignedClientInfo(AssignedClient entity) throws Exception;
    
    public List getRawClientDataUsingLightCustomSearch (String query, String searchString, int firstResultIndex, int maxResults) throws Exception;
    
    public List getRawClientInvoiceDataUsingLightCustomSearch (String searchString, int fromYear, int fromMonth, int toYear, int toMonth,int firstResultIndex, int maxResults) throws Exception;
    
    public int getTotalClientInvoiceInSystemForRange (String searchString,int fromYear, int fromMonth, int toYear, int toMonth) throws Exception;
    
    public List getRawClientPastInvoiceDataUsingLightCustomSearch (String searchString, int toYear, int toMonth,int firstResultIndex, int maxResults) throws Exception;
    
    public List getRawDistinctClientsForInvoiceSearchUsingCustomSearch (String searchString, int fromYear, int fromMonth, int toYear, int toMonth,int firstResultIndex, int maxResults) throws Exception;
    
    public List getRawClientInvoiceApplicationDataUsingCustomSearch (String searchString, Set<Integer> clientIdList, Set<Integer> monthList, Set<Integer> yearList, int fromYear, int fromMonth, int toYear, int toMonth) throws Exception;
    
    public List getRawPropertyNameAndClientIdFromSearchString (String searchString) throws Exception;
    
    public Client getClientFromPropertyName (String propertyName) throws Exception;
}

