/*
 * ClientCustomNoteDao.java
 *
 * Created on June 25, 2006, 2:13 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.ClientCustomNote;

/**
 *
 * @author Mohammed Ansari
 */
public interface ClientCustomNoteDao
{
    
    /** Creates a new instance of ClientCustomNoteDao */
    public ClientCustomNote saveClientCustomNote(ClientCustomNote entity) throws Exception;
    
    public ClientCustomNote updateClientCustomNote(ClientCustomNote entity) throws Exception;
    
}
