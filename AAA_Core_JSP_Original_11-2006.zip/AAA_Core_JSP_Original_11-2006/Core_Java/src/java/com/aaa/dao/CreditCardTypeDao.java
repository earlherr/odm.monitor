/*
 * CreditCardTypeDao.java
 *
 * Created on September 16, 2006, 6:18 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.CreditCardType;

/**
 *
 * @author Mohammed Ansari
 */
public interface CreditCardTypeDao
{
    
    /** Creates a new instance of CreditCardTypeDao */
    public CreditCardType[] getAllCreditCardTypes () throws Exception;
    
}
