/*
 * ApplicationCriteriaDao.java
 *
 * Created on June 14, 2006, 3:07 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.*;

/**
 *
 * @author Mohammed Ansari
 */
public interface ApplicationDecisionStatementDao
{
    
    public ApplicationDecisionStatement saveApplicationDecisionStatement(ApplicationDecisionStatement entity) throws Exception;
    
    public void deleteApplicationDecisionStatement(Integer id) throws Exception;
    
    public ApplicationDecisionStatement updateApplicationDecisionStatement(ApplicationDecisionStatement entity) throws Exception;
}
