/*
 * ApplicantDao.java
 *
 * Created on June 23, 2006, 10:06 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.Applicant;
import java.util.List;

/**
 *
 * @author mansari
 */
public interface ApplicantDao {
    
    public Applicant saveApplicant(Applicant entity) throws Exception;
    
    public Applicant updateApplicant(Applicant entity) throws Exception;
    
    public void deleteApplicant(Integer id) throws Exception;
    
    public List getRawShallowApplicantData (Integer id) throws Exception;
}
