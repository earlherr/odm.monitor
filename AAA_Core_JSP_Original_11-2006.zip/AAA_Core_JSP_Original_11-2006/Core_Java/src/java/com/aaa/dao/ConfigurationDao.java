/*
 * ConfigurationDao.java
 *
 * Created on July 26, 2006, 11:32 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.Configuration;

/**
 *
 * @author Mohammed Ansari
 */
public interface ConfigurationDao
{
    
    /** Creates a new instance of ConfigurationDao */
    public Configuration[] getConfigurationsWithId(Integer id) throws Exception;
    
}
