/*
 * CriminalInfoDao.java
 *
 * Created on July 21, 2006, 3:48 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.CriminalRecord;

/**
 *
 * @author mansari
 */
public interface CriminalRecordDao {
    
    /** Creates a new instance of CriminalInfoDao */
    public CriminalRecord saveCriminalRecord(CriminalRecord entity) throws Exception;
    
    public CriminalRecord updateCriminalRecord(CriminalRecord entity) throws Exception;
    
    public void  deleteCriminalRecord(CriminalRecord entity) throws Exception;
            
    public CriminalRecord[] getCriminalRecordForInfoAndType(Integer criminalInfoId, Integer criminalOffenseTypeId) throws Exception;
}
