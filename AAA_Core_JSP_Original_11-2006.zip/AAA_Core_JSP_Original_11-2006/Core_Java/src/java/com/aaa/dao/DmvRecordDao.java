/*
 * DmvRecordDao.java
 *
 * Created on October 30, 2006, 10:05 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.DmvRecord;

/**
 *
 * @author mansari
 */
public interface DmvRecordDao {
    
    
    public DmvRecord saveDmvRecord(DmvRecord entity) throws Exception;
    
    public DmvRecord updateDmvRecord(DmvRecord entity) throws Exception;
    
    public void  deleteDmvRecord(Integer id) throws Exception;
            
    public DmvRecord[] getDmvRecordForApplicant(Integer applicantId) throws Exception;
    
    public DmvRecord getDmvRecord(Integer id) throws Exception;
    
}
