/*
 * ApplicationTypeDao.java
 *
 * Created on July 16, 2006, 5:19 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.ApplicationType;

/**
 *
 * @author Mohammed Ansari
 */
public interface ApplicationTypeDao
{
    public ApplicationType[] getAllApplicationTypes() throws Exception;
}
