/*
 * GenderDao.java
 *
 * Created on June 23, 2006, 2:03 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.Gender;

/**
 *
 * @author mansari
 */
public interface GenderDao {
    
    /** Creates a new instance of GenderDao */
    public Gender[] getAllGenders () throws Exception;
    
}
