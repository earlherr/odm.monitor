/*
 * AutoDenyCriteriaDao.java
 *
 * Created on July 3, 2006, 2:49 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.AutoDenyCriteria;

/**
 *
 * @author mansari
 */
public interface AutoDenyCriteriaDao {
    
    /** Creates a new instance of AutoDenyCriteriaDao */
    public AutoDenyCriteria[] getAllAutoDenyCriterias() throws Exception;
    
    public AutoDenyCriteria[] getAllAutoDenyCriteriasUsingCategoryId(Integer categoryId) throws Exception;
    
    public AutoDenyCriteria getAutoDenyCriteriaUsingId(Integer id) throws Exception;
    
    public AutoDenyCriteria[] getAllExcludingAutoDenyCriterias(Integer[] excludingIds, Integer categoryId) throws Exception;
    
}
