/*
 * InvoiceDao.java
 *
 * Created on September 17, 2006, 6:46 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.Invoice;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Mohammed Ansari
 */
public interface InvoiceDao
{
    
    public Invoice getInvoice(String invoiceId, Integer clientId) throws Exception;
    
    public Invoice saveInvoice (Invoice invoice) throws Exception;
    
    public Invoice updateInvoice (Invoice invoice) throws Exception;
    
    public List getRawPastDueData (Date beforeThisDate) throws Exception;
    
    public Invoice[] getInvoiceWithSimilarId(String invoiceId) throws Exception;
    
    public void processBatchInvoiceUpdates (List <Invoice> invoices, int batchSize) throws Exception;
    
    public void processBatchInvoiceSaves (List <Invoice> invoices, int batchSize) throws Exception;
}
