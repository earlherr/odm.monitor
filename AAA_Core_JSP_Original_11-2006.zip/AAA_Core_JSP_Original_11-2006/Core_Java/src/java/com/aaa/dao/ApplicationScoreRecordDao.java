/*
 * ApplicationScoreRecordDao.java
 *
 * Created on July 30, 2006, 4:45 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.dao;

import com.aaa.dao.entity.ApplicationScoreRecord;

/**
 *
 * @author Mohammed Ansari
 */
public interface ApplicationScoreRecordDao
{
    
    
    public ApplicationScoreRecord updateApplicationScoreRecord(ApplicationScoreRecord entity) throws Exception;
    
}
