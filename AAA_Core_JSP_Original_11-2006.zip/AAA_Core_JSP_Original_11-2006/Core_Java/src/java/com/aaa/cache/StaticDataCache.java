/*
 * StaticDataCache.java
 *
 * Created on July 28, 2006, 10:11 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.aaa.cache;

import java.util.HashMap;
        
/**
 *
 * @author mansari
 */
public class StaticDataCache 
{  
    public static String ACCESS_LEVELS_CACHE = "accessLevels";    
    public static String APPLICATION_STATUSES_CACHE = "applicationStatuses";
    public static String APPLICATION_TYPES_CACHE = "applicationTypes"; 
    public static String AUTO_DENY_CATEGORIES_CACHE = "autoDenyCategory";
    public static String AUTO_DENY_CRITERIAS_CACHE = "autoDenyCriteria";
    
    public static String PAY_PERIODS_CACHE = "payPeriod";
    public static String GENDERS_CACHE = "gender";
    public static String RENTAL_PERIODS_CACHE = "rentalPeriod";
    public static String STATES_CACHE = "states";    
    public static String STATUS_CACHE = "statuses";
    public static String USER_TYPES_CACHE = "userTypes";
    public static String WORK_TIME_TYPES_CACHE = "workTimeTypessLevels";
    
    public static String MONTHS_CACHE = "months";
    public static String YEARS_CACHE = "years";
    public static String PAYMENT_TYPES_CACHE = "paymentTypes";
    public static String CREDIT_CARD_TYPES_CACHE = "creditCardTypes";
    
    
    private static final HashMap Cache = new HashMap ();
    
    /** Creates a new instance of StaticDataCache */
    public StaticDataCache() {
    }
    
    public static Object[] getCache(String key)
    {
        return (Object[]) Cache.get(key);
    }
    
    public static void putCache (String key, Object[] cache)
    {
        Cache.put(key, cache);
    }
    
    public static HashMap getMap ()
    {
        return Cache;
    }
    
}
