
var requestStatusArr = new Array();
requestStatusArr['waiting'] = 0;
requestStatusArr['accepted'] = 1;
requestStatusArr['refused'] = 2;
requestStatusArr['timeout'] = 3;

var userStatusArr = new Array();
userStatusArr['online'] = 1;
userStatusArr['offline'] = 2;
userStatusArr['busy'] = 3;
userStatusArr['away'] = 4;
userStatusArr['outToLunch'] = 5;
userStatusArr['onThePhone'] = 6;
userStatusArr['beRightBack'] = 7;

var userStatusLabelArr = new Array();
userStatusLabelArr[1] = 'Online';
userStatusLabelArr[2] = 'Offline';
userStatusLabelArr[3] = 'Busy';
userStatusLabelArr[4] = 'Away';
userStatusLabelArr[5] = 'Out To Lunch';
userStatusLabelArr[6] = 'On The Phone';
userStatusLabelArr[7] = 'Be Right Back';

var chatRequestTypeArr = new Array();
chatRequestTypeArr['clientRequest'] = 1;
chatRequestTypeArr['agentInvite'] = 2;
chatRequestTypeArr['agentTransfer'] = 3;

function enterSubmit(callBackMethod, e) {
   if (!e) e = window.event
    if (e.keyCode) code = e.keyCode;
    else if (e.which) code = e.which;
    if (code == 13){
        callBackMethod();
        return false;
    }
    return true;
}

function appendTextToDiv(divId, data){
    var targetDiv = document.getElementById(divId);
    if(targetDiv.innerHTML == ""){
        targetDiv.innerHTML = data;
    }
    else{
        targetDiv.innerHTML = targetDiv.innerHTML + "<br>" + data;
    }
//    var newDiv = document.createElement("div");
//    newDiv.innerHTML = data;
//    var targetDiv = document.getElementById(divId);
//    targetDiv.appendChild(newDiv);
    targetDiv.scrollTop = targetDiv.scrollHeight;
}

function st_encode(str){
    if(str == null || str == undefined) return str;
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function formatFeedbackMessage(msg){
    return "<font color='#808080'>" + st_encode(msg) + "</font>";
}

function formatTimePeriod(period){
    var mins = Math.floor(period / 60);
    var seconds = period % 60;
    mins = mins % 60;
    var hours = Math.floor(mins / 60);

    var duration = "";
    if(hours > 0){
        duration = duration + hours + " hour ";
    }
    if(mins > 0){
        duration = duration + mins + " min ";
    }
    duration = duration + seconds + " sec ";
    return duration;
}

function currentTime(){
    var now = new Date();
    var hours = now.getHours() == 12? 12 : now.getHours() % 12;
    var mins = now.getMinutes() >= 10? now.getMinutes() : "0" + now.getMinutes();
    var secs = now.getSeconds() >= 10? now.getSeconds() : "0" + now.getSeconds();
    var suffix = now.getHours() >= 12 ? " PM" : " AM";
    return hours + ":" + mins + ":" + secs + suffix;
}

function printKeyCode(msg){
    for(var i=0; i<msg.length; i++){
        alert(msg.charCodeAt(i));
    }
}

function trimSpecialCharAndSpace(msg){
    //remove leading special character
    if(msg.length == 0) return msg;
    var i=0;
    var index = 0;
    while(msg.charCodeAt(i) >= 0 && msg.charCodeAt(i) <= 32){
        index = ++i;
    }
    if(index > 0) msg = msg.substring(index, msg.length);
    //remove trailing special character
    i = msg.length -1;
    index = msg.length -1;
    while(msg.charCodeAt(i) >=0 && msg.charCodeAt(i) <= 32){
        index = --i;
    }
    if(index < msg.length -1) msg = msg.substring(0, index+1);

    return msg;
}

function removeItemFromArr(arr, item){
    var result = new Array();
    for(var i=0; i<arr.length; i++){
        if(arr[i] != item){
            result[result.length] = arr[i];
        }
    }
    return result;
}

ns4 = document.layers;
ie4 = document.all;
nn6 = document.getElementById && !document.all;
function showObjectToEvent(e, obName) {
    if (ns4) {
       document.obName.visibility = "show";
       document.obName.left = e.pageX;
       document.obName.top = e.pageY;
    }
    else if (ie4) {
       document.all[obName].style.visibility = "visible";
       document.all[obName].style.left = e.clientX + document.body.scrollLeft;
       document.all[obName].style.top = e.clientY + document.body.scrollTop;
    }
    else if (nn6) {
       document.getElementById(obName).style.visibility = "visible";
       document.getElementById(obName).style.left = e.clientX + document.body.scrollLeft;
       docume.getElementById(obName).style.top = e.clientY + document.body.scrollTop;
    }
}

function showObject(obName){
    if (ns4) {
       document.obName.visibility = "show";
    }
    else if (ie4) {
       document.all[obName].style.visibility = "visible";
    }
    else if (nn6) {
       document.getElementById(obName).style.visibility = "visible";
    }
}
function hideObject(obName) {
    if (ns4) {
       document.obName.visibility = "hide";
    }
    else if (ie4) {
       document.all[obName].style.visibility = "hidden";
    }
    else if (nn6) {
       document.getElementById(obName).style.visibility = "hidden";
    }
    if(obName == 'inviteOrTransfer'){
        hideSuggestDiv();
    }
}

function doHttpRemoteCall(sendContent, callBackMethod) {
  try{
      var request = get_XMLHttpRequest();
      request.open('POST', "xmlHttpRemote.do", false);//async = false
      request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      request.send(sendContent);

       if (request.readyState == 4) {
            if (request.status == 200) {  // only if "OK"
                  var response = request.responseText;
                  if (response == "NOT_LOGGED_IN") {
                      alert("Either you have not logged in or your session has timed out!");
                      _ifEndPull = true;
                      return; //todo: go to the login page...
                  }

                   if(callBackMethod != null){
                       callBackMethod( response );
                   }
            } else {
                alert("There was a problem retrieving data from server:\n" + request.statusText);
            }
        }
    }catch(e){
       if(("" + callBackMethod).indexOf('callbackForPull') != -1){
           callBackMethod("retry");
       }
       else{//for any send requests
           if(e.message != null && e.message.length > 0){
              alert(e.message);
           }
           else{
               alert("Error in sending message.")
           }
       }
    }
}

function get_XMLHttpRequest() {
    try {
        return new ActiveXObject("Microsoft.XMLHTTP")
    } catch (exception) {
        return new XMLHttpRequest();
    }
}


function DWREngine()
{
}

{
DWREngine._utf8 = function(wide)
{
var c;
var s;
var enc = "";
var i = 0;

while (i < wide.length)
{
c = wide.charCodeAt(i++);

if (c >= 0xDC00 && c < 0xE000)
{
continue;
}

if (c >= 0xD800 && c < 0xDC00)
{
if (i >= wide.length)
{
continue;
}

s = wide.charCodeAt(i++);
if (s<0xDC00 || c>=0xDE00)
{
continue;
}

c = ((c - 0xD800) << 10) + (s - 0xDC00) + 0x10000;
}


if (c < 0x80)
{
enc += String.fromCharCode(c);
}
else if (c < 0x800)
{
enc += String.fromCharCode(0xC0 + (c >> 6), 0x80 + (c & 0x3F));
}
else if (c < 0x10000)
{
enc += String.fromCharCode(0xE0 + (c >> 12), 0x80 + (c >> 6 & 0x3F), 0x80 + (c & 0x3F));
}
else
{
enc += String.fromCharCode(0xF0 + (c >> 18), 0x80 + (c >> 12 & 0x3F), 0x80 + (c >> 6 & 0x3F), 0x80 + (c & 0x3F));
}
}

return enc;
}

DWREngine._hexchars = "0123456789ABCDEF";

DWREngine._toHex = function(n)
{
return DWREngine._hexchars.charAt(n >> 4) + DWREngine._hexchars.charAt(n & 0xF);
}

DWREngine._okURIchars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-";

function encodeURIComponent(s)
{
s = DWREngine._utf8(s);
var c;
var enc = "";

for (var i= 0; i<s.length; i++)
{
if (DWREngine._okURIchars.indexOf(s.charAt(i)) == -1)
{
enc += "%" + DWREngine._toHex(s.charCodeAt(i));
}
else
{
enc += s.charAt(i);
}
}

return enc;
}
}

