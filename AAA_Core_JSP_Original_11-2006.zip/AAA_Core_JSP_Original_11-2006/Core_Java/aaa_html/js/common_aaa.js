// JavaScript Document
function highlight(obj) 
{
   obj.className = 'inputTextHighlight';
}

// REMOVES THE HIGHLIGHT ON BLUR
function blank(obj) 
{
  obj.className = 'inputText';
}


/** Table roll overs */
function highlightRow(obj, color) 
{
   obj.style.backgroundColor =  color;
}

function removeHighlightRow(obj, color) 
{
   obj.style.backgroundColor = color;
}

function popUp(strURL,strType,strHeight,strWidth) 
{
	var strOptions="";
	if (strType=="console") strOptions="resizable,height="+strHeight+",width="+strWidth;
	if (strType=="fixed") strOptions="status,height="+strHeight+",width="+strWidth;
	if (strType=="elastic") strOptions="toolbar,menubar,scrollbars,resizable,location,height="+strHeight+",width="+strWidth;
	window.open(strURL, 'newWin', strOptions);
}